"""
Simple authentication system for RateWise application
"""
import streamlit as st
from database import get_db_manager
import hashlib
import uuid

class AuthManager:
    """Simple authentication manager"""
    
    def __init__(self):
        self.db_manager = get_db_manager()
    
    def is_authenticated(self) -> bool:
        """Check if user is authenticated"""
        return 'user_id' in st.session_state and st.session_state.user_id is not None
    
    def get_current_user(self):
        """Get current authenticated user"""
        if not self.is_authenticated():
            return None
        
        return {
            'id': st.session_state.user_id,
            'email': st.session_state.get('user_email', ''),
            'name': st.session_state.get('user_name', ''),
            'company_name': st.session_state.get('company_name', ''),
            'user_type': st.session_state.get('user_type', 'paid'),
            'is_free_trial': st.session_state.get('user_type', 'paid') == 'free_trial'
        }
    
    def login_form(self):
        """Display login form"""
        st.markdown("### Login to RateWise")
        
        # Add tabs for different login types
        tab1, tab2 = st.tabs(["Full Access", "Free Trial"])
        
        with tab1:
            st.markdown("**Full platform access with all features**")
            with st.form("login_form"):
                access_password = st.text_input("Access Password", type="password", placeholder="Enter your access password")
                email = st.text_input("Email Address", placeholder="your@company.com")
                name = st.text_input("Full Name", placeholder="John Doe")
                company_name = st.text_input("Company Name (Optional)", placeholder="Your Company Inc.")
                
                submitted = st.form_submit_button("Continue to RateWise", type="primary")
                
                if submitted:
                    self._process_full_access_login(access_password, email, name, company_name)
        
        with tab2:
            st.markdown("**Try RateWise with limited features - Upload & Audit + Dashboard only**")
            with st.form("free_trial_form"):
                trial_password = st.text_input("Free Trial Password", type="password", placeholder="Enter trial password")
                trial_email = st.text_input("Email Address", placeholder="your@company.com", key="trial_email")
                trial_name = st.text_input("Full Name", placeholder="John Doe", key="trial_name")
                
                trial_submitted = st.form_submit_button("Start Free Trial", type="secondary")
                
                if trial_submitted:
                    self._process_free_trial_login(trial_password, trial_email, trial_name)
    
    def _process_full_access_login(self, password: str, email: str, name: str, company_name: str):
        """Process full access login"""
        # Validate access password first
        if password != "RATEWISE2025":
            st.error("Invalid access password. Please contact support to upgrade from free trial.")
            return
        
        if email and name:
            try:
                # Create or get user
                user = self.db_manager.create_or_get_user(
                    email=email,
                    name=name,
                    company_name=company_name
                )
                
                # Set session state for full access
                st.session_state.user_id = user.id
                st.session_state.user_email = user.email
                st.session_state.user_name = user.name
                st.session_state.company_name = user.company_name or company_name
                st.session_state.user_type = 'paid'
                
                st.success(f" Welcome back, {name}!")
                st.rerun()
                
            except Exception as e:
                st.error(f"Database connection error. Please try again in a moment.")
                st.warning("Running in demo mode - your data will not be saved.")
                
                # Set temporary session state for demo mode
                import time
                st.session_state.user_id = int(time.time())  # Use timestamp as temp ID
                st.session_state.user_email = email
                st.session_state.user_name = name
                st.session_state.company_name = company_name
                st.session_state.user_type = 'paid'
                st.session_state.demo_mode = True
                
                st.info(" You can still use all features - just without data persistence.")
                st.rerun()
        else:
            st.error("Please fill in all required fields")
    
    def _process_free_trial_login(self, password: str, email: str, name: str):
        """Process free trial login"""
        if password == "FREEAUDIT25":
            if email and name:
                # Set session state for free trial
                import time
                st.session_state.user_id = f"trial_{int(time.time())}"
                st.session_state.user_email = email
                st.session_state.user_name = name
                st.session_state.company_name = "Free Trial User"
                st.session_state.user_type = 'free_trial'
                st.session_state.demo_mode = True  # Free trial users don't get data persistence
                
                st.success(f" Welcome to your free trial, {name}!")
                st.info(" You have access to Upload & Audit and Dashboard features. Upgrade for full access!")
                st.rerun()
            else:
                st.error("Please fill in all required fields")
        else:
            st.error("Invalid trial password. Please contact support for access.")
            
    
    def logout(self):
        """Logout current user"""
        for key in ['user_id', 'user_email', 'user_name', 'company_name', 'user_type', 'demo_mode']:
            if key in st.session_state:
                del st.session_state[key]
        st.rerun()
    
    def require_auth(self):
        """Decorator/check to require authentication"""
        if not self.is_authenticated():
            self.login_form()
            st.stop()
    
    def is_free_trial_user(self) -> bool:
        """Check if current user is a free trial user"""
        return st.session_state.get('user_type', 'paid') == 'free_trial'
    
    def is_paid_user(self) -> bool:
        """Check if current user has paid access"""
        return st.session_state.get('user_type', 'paid') == 'paid'
    
    def get_allowed_pages(self) -> list:
        """Get list of pages allowed for current user"""
        if self.is_free_trial_user():
            return ["Upload & Audit", "Dashboard"]
        else:
            return ["Upload & Audit", "Refund Recovery", "Dashboard", "Generate Report", 
                   "Export Data", "Audit History", "QuickBooks Export", "Email Reports", 
                   "Contract Review", "AI Freight Advisor"]
    
    def check_page_access(self, page: str) -> bool:
        """Check if current user can access a specific page"""
        return page in self.get_allowed_pages()
    
    def sidebar_user_info(self):
        """Display user info in sidebar"""
        if self.is_authenticated():
            user = self.get_current_user()
            
            with st.sidebar:
                st.markdown("---")
                st.markdown(f"**Logged in as:**")
                st.markdown(f"{user['name']}")
                st.markdown(f"{user['company_name'] or 'Personal'}")
                st.markdown(f"{user['email']}")
                
                # Show user type
                if self.is_free_trial_user():
                    st.markdown("**🔓 Free Trial Access**")
                    st.markdown("*Upgrade for full features*")
                else:
                    st.markdown("**✅ Full Access**")
                
                if st.button("Logout", key="logout_btn"):
                    self.logout()

# Global auth manager instance
auth_manager = AuthManager()

def get_auth_manager():
    """Get the global auth manager instance"""
    return auth_manager