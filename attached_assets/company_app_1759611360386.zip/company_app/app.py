import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import base64
import io
import os

from audit_engine import FreightAuditEngine
from pdf_generator import PDFGenerator
from data_validator import DataValidator
from visualization import VisualizationManager
from utils import format_currency, calculate_savings_summary
from auth import get_auth_manager
from database import get_db_manager
from quickbooks_export import QuickBooksExporter
from email_manager import EmailManager

# Page configuration
st.set_page_config(
    page_title="RateWise - Freight Audit Platform",
    page_icon="",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for RateWise branding
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #1F497D 0%, #FFA947 100%);
        color: white;
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        text-align: center;
    }
    .metric-card {
        background: white;
        padding: 1rem;
        border-radius: 10px;
        border-left: 4px solid #FFA947;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .error-card {
        background: #fff5f5;
        border: 1px solid #feb2b2;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
    }
    .success-card {
        background: #f0fff4;
        border: 1px solid #9ae6b4;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
    }
</style>
""", unsafe_allow_html=True)

def get_logo_base64():
    """Convert logo image to base64 for HTML embedding"""
    try:
        with open("attached_assets/image_1758140502894.png", "rb") as img_file:
            return base64.b64encode(img_file.read()).decode()
    except Exception as e:
        # Fallback if logo not found
        return ""

def display_header():
    """Display RateWise header with branding"""
    st.markdown("""
    <div class="main-header">
        <h1>RateWise</h1>
        <p>Freight Audit Platform - Maximize Your Shipping Savings</p>
    </div>
    """, unsafe_allow_html=True)

def display_data_requirements():
    """Display data upload requirements and instructions"""
    with st.expander("Data Upload Requirements", expanded=False):
        st.markdown("""
        ### Required Data Format
        Upload your shipment data as **CSV** or **Excel** files with the following columns:
        
        **Required Columns:**
        - `Carrier` - FedEx, UPS, etc.
        - `Service Type` - Ground, Express, Priority, etc.
        - `Shipment Date` - Date format (YYYY-MM-DD or MM/DD/YYYY)
        - `Delivery Date` - Actual delivery date
        - `Tracking Number` - Unique tracking identifier
        - `Zone` - Shipping zone (1-8)
        - `Origin ZIP` - Sender ZIP code
        - `Destination ZIP` - Recipient ZIP code
        - `Address Type` - Residential or Commercial
        - `Total Charges` - Total amount charged
        - `Base Rate` - Base shipping rate
        - `Surcharges` - Additional fees
        - `Actual Weight` - Package weight in lbs
        - `DIM Weight` - Dimensional weight
        - `Length`, `Width`, `Height` - Package dimensions in inches
        
        **Optional Columns:**
        - `Declared Value` - Insurance value
        - `Fuel Surcharge` - Fuel charges
        - `Residential Surcharge` - Residential delivery fee
        - `Address Correction` - Address correction fees
        """)

def main():
    # Initialize auth and database
    auth = get_auth_manager()
    db = get_db_manager()
    
    # Check authentication
    if not auth.is_authenticated():
        display_header()
        auth.login_form()
        return
    
    # Initialize session state
    if 'audit_results' not in st.session_state:
        st.session_state.audit_results = None
    if 'uploaded_data' not in st.session_state:
        st.session_state.uploaded_data = None
    if 'actionable_errors' not in st.session_state:
        st.session_state.actionable_errors = None
    if 'submitted_claims' not in st.session_state:
        st.session_state.submitted_claims = []
    if 'selected_claims' not in st.session_state:
        st.session_state.selected_claims = []
    
    # Sidebar for navigation
    with st.sidebar:
        # RateWise button - dark blue with white text
        st.markdown("""
        <style>
        .ratewise-button {
            background-color: #1F497D;
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            text-align: center;
            font-size: 22px;
            font-weight: bold;
            border: none;
            width: 100%;
            margin-bottom: 10px;
        }
        </style>
        <div class="ratewise-button">
            RateWise
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("---")
        
        # Show user info
        auth.sidebar_user_info()
        
        st.markdown("---")
        
        # Navigation menu - only show pages allowed for current user
        allowed_pages = auth.get_allowed_pages()
        page = st.selectbox(
            "Select Page",
            allowed_pages
        )
        
        # Show upgrade message for free trial users
        if auth.is_free_trial_user():
            st.markdown("---")
            st.markdown("**🚀 Upgrade for Full Access**")
            st.markdown("*Get access to all features including:*")
            st.markdown("• Refund Recovery & Claims")
            st.markdown("• PDF Report Generation")
            st.markdown("• Data Export & QuickBooks")
            st.markdown("• Email Automation")
            st.markdown("• Contract Analysis")
            st.markdown("• AI Freight Advisor")
    
    # Display main header conditionally (skip for AI Freight Advisor, Contract Review, and Email Reports)
    if page not in ["AI Freight Advisor", "Contract Review", "Email Reports"]:
        display_header()
    
    # Main content area with access control
    if page == "Upload & Audit":
        upload_and_audit_page()
    elif page == "Refund Recovery":
        if auth.check_page_access(page):
            refund_recovery_page()
        else:
            show_upgrade_required_page()
    elif page == "Dashboard":
        dashboard_page()
    elif page == "Generate Report":
        if auth.check_page_access(page):
            generate_report_page()
        else:
            show_upgrade_required_page()
    elif page == "Export Data":
        if auth.check_page_access(page):
            export_data_page()
        else:
            show_upgrade_required_page()
    elif page == "Audit History":
        if auth.check_page_access(page):
            audit_history_page()
        else:
            show_upgrade_required_page()
    elif page == "QuickBooks Export":
        if auth.check_page_access(page):
            quickbooks_export_page()
        else:
            show_upgrade_required_page()
    elif page == "Email Reports":
        if auth.check_page_access(page):
            email_reports_page()
        else:
            show_upgrade_required_page()
    elif page == "Contract Review":
        if auth.check_page_access(page):
            contract_review_page()
        else:
            show_upgrade_required_page()
    elif page == "AI Freight Advisor":
        if auth.check_page_access(page):
            ai_freight_advisor_page()
        else:
            show_upgrade_required_page()

def show_upgrade_required_page():
    """Show upgrade required message for free trial users"""
    st.header("🚀 Upgrade Required")
    
    st.markdown("""
    <div style="background: linear-gradient(90deg, #1F497D 0%, #FFA947 100%); color: white; padding: 2rem; border-radius: 10px; margin-bottom: 2rem;">
        <h3 style="color: white; margin: 0;">This feature requires a paid subscription</h3>
        <p style="margin: 0.5rem 0 0 0;">You're currently using the free trial with limited access</p>
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🔓 **Your Current Access (Free Trial)**")
        st.markdown("✅ Upload & Audit shipment data")
        st.markdown("✅ View dashboard with basic analytics")
        st.markdown("❌ Download reports and data")
        st.markdown("❌ Generate professional PDFs")
        st.markdown("❌ Access refund recovery tools")
        st.markdown("❌ QuickBooks integration")
        st.markdown("❌ Email automation")
        st.markdown("❌ Contract analysis")
        st.markdown("❌ AI freight advisor")
    
    with col2:
        st.markdown("### ✨ **Full Access Benefits**")
        st.markdown("• **Professional PDF Reports** - Share with management")
        st.markdown("• **Automated Refund Claims** - Recover overcharges automatically")
        st.markdown("• **QuickBooks Integration** - Seamless accounting")
        st.markdown("• **Email Automation** - Stay informed with scheduled reports")
        st.markdown("• **Contract Analysis** - Optimize your carrier agreements")
        st.markdown("• **AI Freight Advisor** - Get expert shipping recommendations")
        st.markdown("• **Data Export** - Download all your findings")
        st.markdown("• **Audit History** - Track your savings over time")
    
    st.markdown("---")
    st.markdown("### 💰 **Ready to unlock the full power of RateWise?**")
    st.info("Contact us to upgrade your account and start saving more on shipping costs!")
    
    col1, col2, col3 = st.columns(3)
    with col2:
        if st.button("🚀 Upgrade Now", type="primary", use_container_width=True):
            st.markdown("📧 **Contact us at:** sales@ratewiseconsulting.com")
            st.markdown("📞 **Call us to upgrade:** Available during business hours")

def upload_and_audit_page():
    """Handle file upload and initial audit"""
    st.header(" Upload Shipment Data")
    
    display_data_requirements()
    
    # File upload options
    upload_mode = st.radio(
        "Upload Method",
        ["Single File (Shipment Details Only)", "Merge Files (Shipment Details + Surcharge Report)"],
        help="Choose whether to upload just shipment data or merge with separate surcharge file"
    )
    
    if upload_mode == "Single File (Shipment Details Only)":
        # Original single file upload
        uploaded_file = st.file_uploader(
            "Choose a CSV or Excel file",
            type=['csv', 'xlsx', 'xls'],
            help="Upload your FedEx/UPS shipment data for audit analysis"
        )
        surcharge_file = None
        
    else:
        # Dual file upload for merging
        st.markdown("### Upload Both Files for Merging")
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Shipment Details File**")
            uploaded_file = st.file_uploader(
                "Shipment Details",
                type=['csv', 'xlsx', 'xls'],
                help="Main shipment data file with tracking numbers, weights, costs, etc.",
                key="shipment_file"
            )
            
        with col2:
            st.markdown("**Surcharge Report File**")
            surcharge_file = st.file_uploader(
                "Surcharge Report", 
                type=['csv', 'xlsx', 'xls'],
                help="Surcharge file with tracking numbers and surcharge amounts",
                key="surcharge_file"
            )
            
        if uploaded_file is not None and surcharge_file is not None:
            st.info("Both files uploaded! The surcharge amounts will be merged with shipment details by tracking number.")
    
    if uploaded_file is not None:
        try:
            # Load data
            validator = DataValidator()
            
            # Handle file merging if surcharge file is present
            if upload_mode == "Merge Files (Shipment Details + Surcharge Report)" and surcharge_file is not None:
                merge_result, error_message = validator.merge_shipment_and_surcharge_files(uploaded_file, surcharge_file)
                if merge_result is not None:
                    df = merge_result
                    st.success(f"Files merged successfully! Found {len(df)} shipments with updated surcharge totals.")
                else:
                    st.error(f"File merge failed: {error_message}")
                    st.info("Please check that your surcharge file contains tracking numbers and surcharge amounts, then try again.")
                    return
            else:
                df = validator.load_file(uploaded_file)
                
            if df is not None:
                if upload_mode == "Single File (Shipment Details Only)":
                    st.success(f"File uploaded successfully! Found {len(df)} shipments.")
                
                # Display data preview
                with st.expander("Data Preview", expanded=True):
                    st.dataframe(df.head(10), use_container_width=True)
                
                # Validate required columns
                validation_results = validator.validate_columns(df)
                
                if validation_results.get('is_valid', False):
                    st.success("All required columns found!")
                    
                    # Clean and prepare data
                    cleaned_df = validator.clean_data(df)
                    st.session_state.uploaded_data = cleaned_df
                    
                    # Run audit button
                    if st.button("Run Freight Audit", type="primary"):
                        with st.spinner("Running comprehensive freight audit..."):
                            audit_engine = FreightAuditEngine()
                            audit_results = audit_engine.run_full_audit(cleaned_df)
                            st.session_state.audit_results = audit_results
                            
                            # Filter actionable errors for refund claims
                            actionable_errors = audit_engine.get_actionable_errors(audit_results['findings'])
                            st.session_state.actionable_errors = actionable_errors
                            
                            # Save to database if not in demo mode
                            auth = get_auth_manager()
                            user = auth.get_current_user()
                            
                            if not st.session_state.get('demo_mode', False):
                                try:
                                    db = get_db_manager()
                                    session_id = db.save_audit_session(
                                        user_id=user['id'],
                                        filename=uploaded_file.name,
                                        audit_results=audit_results,
                                        findings_df=audit_results['findings']
                                    )
                                    st.session_state.current_session_id = session_id
                                    
                                    # Display success message with actionable errors summary
                                    if not actionable_errors.empty:
                                        total_actionable_savings = actionable_errors['Refund Estimate'].sum()
                                        st.success(f"Audit completed and saved! Found {len(actionable_errors)} actionable errors with ${total_actionable_savings:,.2f} in potential refunds.")
                                        st.info("Visit the Refund Recovery page to submit claims for these errors.")
                                    else:
                                        st.success("Audit completed and saved! Check the Dashboard for results.")
                                        
                                except Exception as e:
                                    st.warning(f"Audit completed but couldn't save to history. Running in demo mode.")
                                    st.session_state.demo_mode = True
                                    
                                    # Display success message with actionable errors summary
                                    if not actionable_errors.empty:
                                        total_actionable_savings = actionable_errors['Refund Estimate'].sum()
                                        st.success(f"Audit completed! Found {len(actionable_errors)} actionable errors with ${total_actionable_savings:,.2f} in potential refunds.")
                                        st.info("Visit the Refund Recovery page to submit claims for these errors.")
                                    else:
                                        st.success("Audit completed! Check the Dashboard for results.")
                            else:
                                # Display success message with actionable errors summary
                                if not actionable_errors.empty:
                                    total_actionable_savings = actionable_errors['Refund Estimate'].sum()
                                    st.success(f"Audit completed! Found {len(actionable_errors)} actionable errors with ${total_actionable_savings:,.2f} in potential refunds.")
                                    st.info("Visit the Refund Recovery page to submit claims for these errors.")
                                else:
                                    st.success("Audit completed! Check the Dashboard for results.")
                                st.info("Running in demo mode - results won't be saved to history.")
                            
                            # Email notification option - restricted for free trial users
                            if auth.is_paid_user():
                                with st.expander("Email Audit Results"):
                                    col1, col2 = st.columns(2)
                                    with col1:
                                        email_recipient = st.text_input("Email Address", value=user.get('email', ''))
                                    with col2:
                                        include_pdf = st.checkbox("Include PDF Report", value=True)
                                    
                                    if st.button("Send Email Report"):
                                        if email_recipient:
                                            try:
                                                # Check if SendGrid is configured
                                                if 'SENDGRID_API_KEY' in os.environ:
                                                    email_manager = EmailManager()
                                                    
                                                    # Generate PDF if requested
                                                    pdf_data = None
                                                    if include_pdf:
                                                        pdf_gen = PDFGenerator()
                                                        pdf_data = pdf_gen.generate_audit_report(
                                                            audit_results,
                                                            user.get('name', 'User'),
                                                            user.get('company_name', 'Your Company')
                                                        )
                                                    
                                                    # Send email
                                                    success = email_manager.send_audit_complete_email(
                                                        to_email=email_recipient,
                                                        audit_results=audit_results,
                                                        findings_df=audit_results['findings'],
                                                        user_name=user.get('name', 'User'),
                                                        company_name=user.get('company_name'),
                                                        pdf_attachment=pdf_data
                                                    )
                                                    
                                                    if success:
                                                        st.success("Email sent successfully!")
                                                    else:
                                                        st.error("Failed to send email. Please try again.")
                                                else:
                                                    st.warning("Email service not configured. Please set up SendGrid API key.")
                                            
                                            except Exception as e:
                                                st.error(f"Email error: Please ensure SendGrid is properly configured.")
                                    else:
                                        st.error("Please enter an email address.")
                            else:
                                # Show upgrade message for free trial users
                                st.markdown("""
                                <div style="background: linear-gradient(90deg, #1F497D 0%, #FFA947 100%); color: white; padding: 1rem; border-radius: 8px; margin: 1rem 0;">
                                    <h4 style="color: white; margin: 0;">🚀 Upgrade to Download Reports</h4>
                                    <p style="margin: 0.5rem 0 0 0;">Get email reports and PDF downloads with a paid subscription</p>
                                </div>
                                """, unsafe_allow_html=True)
                            
                        st.rerun()
                
                else:
                    st.error("Missing required columns:")
                    missing_cols = validation_results.get('missing_columns', [])
                    for missing_col in missing_cols:
                        st.error(f"• {missing_col}")
                    
                    st.info("Please ensure your file contains all required columns.")
        
        except Exception as e:
            st.error(f"Error processing file: {str(e)}")

def refund_recovery_page():
    """Handle refund claim submission and tracking"""
    st.header("Refund Recovery")
    
    # Check if actionable errors are available
    if st.session_state.actionable_errors is None or st.session_state.actionable_errors.empty:
        st.markdown("""
        <div class="error-card">
            <h3>No Actionable Errors Found</h3>
            <p>Please run a freight audit on the Upload & Audit page to identify potential refund opportunities.</p>
        </div>
        """, unsafe_allow_html=True)
        
        if st.button("Go to Upload & Audit", type="primary"):
            st.rerun()
        return
    
    actionable_errors = st.session_state.actionable_errors
    
    # Summary section
    st.subheader("Claim Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        total_claims = len(actionable_errors)
        st.markdown(f"""
        <div class="metric-card">
            <h3>Total Claims</h3>
            <h2 style="color: #1F497D;">{total_claims}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        total_potential = actionable_errors['Refund Estimate'].sum()
        st.markdown(f"""
        <div class="metric-card">
            <h3>Potential Recovery</h3>
            <h2 style="color: #FFA947;">{format_currency(total_potential)}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        high_priority = len(actionable_errors[actionable_errors['Claim Priority'] == 'High'])
        st.markdown(f"""
        <div class="metric-card">
            <h3>High Priority</h3>
            <h2 style="color: #d32f2f;">{high_priority}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        ready_to_submit = len(actionable_errors[actionable_errors['Claim Status'] == 'Ready to Submit'])
        st.markdown(f"""
        <div class="metric-card">
            <h3>Ready to Submit</h3>
            <h2 style="color: #2e7d32;">{ready_to_submit}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Filters and sorting
    st.subheader("Filter Claims")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        error_types = ['All'] + list(actionable_errors['Error Type'].unique())
        selected_error_type = st.selectbox("Error Type", error_types)
    
    with col2:
        priorities = ['All'] + list(actionable_errors['Claim Priority'].unique())
        selected_priority = st.selectbox("Priority Level", priorities)
    
    with col3:
        min_refund = st.number_input("Min Refund Amount ($)", min_value=0.0, value=0.0)
    
    # Apply filters
    filtered_claims = actionable_errors.copy()
    
    if selected_error_type != 'All':
        filtered_claims = filtered_claims[filtered_claims['Error Type'] == selected_error_type]
    
    if selected_priority != 'All':
        filtered_claims = filtered_claims[filtered_claims['Claim Priority'] == selected_priority]
    
    if min_refund > 0:
        filtered_claims = filtered_claims[filtered_claims['Refund Estimate'] >= min_refund]
    
    st.markdown("---")
    
    # Claims table with selection
    st.subheader("Actionable Claims")
    
    if not filtered_claims.empty:
        # Sort by refund amount (highest first)
        filtered_claims = filtered_claims.sort_values('Refund Estimate', ascending=False)
        
        # Reset selected claims when filtering changes
        current_filter_key = f"{selected_error_type}_{selected_priority}_{min_refund}"
        if st.session_state.get('last_filter_key') != current_filter_key:
            st.session_state.selected_claims = []
            st.session_state.last_filter_key = current_filter_key
        
        # Select all checkbox
        select_all = st.checkbox("Select All Claims", key="select_all_claims")
        
        # Handle select all functionality
        if select_all:
            st.session_state.selected_claims = list(filtered_claims.index)
        
        # Display claims in a clean format
        for idx, (index, claim) in enumerate(filtered_claims.iterrows()):
            with st.container():
                col1, col2 = st.columns([1, 10])
                
                with col1:
                    # Individual checkbox
                    is_individually_selected = index in st.session_state.selected_claims
                    checkbox_value = st.checkbox("", key=f"claim_{idx}", value=is_individually_selected)
                    
                    # Update selection state
                    if checkbox_value and index not in st.session_state.selected_claims:
                        st.session_state.selected_claims.append(index)
                    elif not checkbox_value and index in st.session_state.selected_claims:
                        st.session_state.selected_claims.remove(index)
                
                with col2:
                    # Priority color coding
                    priority_colors = {
                        'High': '#d32f2f',
                        'Medium': '#f57c00', 
                        'Low': '#388e3c'
                    }
                    priority_color = priority_colors.get(claim['Claim Priority'], '#666666')
                    
                    st.markdown(f"""
                    <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 1rem; margin: 0.5rem 0; border-left: 4px solid {priority_color};">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                            <strong style="color: #1F497D; font-size: 1.1em;">Tracking: {claim['Tracking Number']}</strong>
                            <span style="background: {priority_color}; color: white; padding: 0.2rem 0.5rem; border-radius: 4px; font-size: 0.8em;">{claim['Claim Priority']} Priority</span>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin: 0.5rem 0;">
                            <div><strong>Error Type:</strong> {claim['Error Type']}</div>
                            <div><strong>Carrier:</strong> {claim['Carrier']}</div>
                            <div><strong>Service:</strong> {claim['Service Type']}</div>
                        </div>
                        <div style="margin: 0.5rem 0;">
                            <strong>Dispute Reason:</strong> {claim['Dispute Reason']}
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span><strong>Date:</strong> {claim['Date']}</span>
                            <span style="color: #FFA947; font-size: 1.2em; font-weight: bold;">Refund: {format_currency(claim['Refund Estimate'])}</span>
                        </div>
                        {f"<div style='color: #666; font-size: 0.9em; margin-top: 0.5rem;'><strong>Notes:</strong> {claim.get('Notes', 'N/A')}</div>" if claim.get('Notes') else ""}
                    </div>
                    """, unsafe_allow_html=True)
        
        st.markdown("---")
        
        # Claim submission section
        if st.session_state.selected_claims:
            st.subheader("Submit Claims")
            
            # Calculate totals for selected claims
            selected_df = filtered_claims.loc[st.session_state.selected_claims]
            
            total_selected = len(selected_df)
            total_recovery = selected_df['Refund Estimate'].sum()
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.info(f" **Selected Claims:** {total_selected}")
                st.info(f" **Total Recovery:** {format_currency(total_recovery)}")
            
            with col2:
                claim_method = st.radio(
                    "Submission Method:",
                    ["Automatic Submission", "Email to Carrier", "Download Dispute Package"],
                    help="Choose how you'd like to submit these claims"
                )
            
            # Submit button
            if st.button(" Submit Selected Claims", type="primary", use_container_width=True):
                # Simulate claim submission
                submitted_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                
                # Get current user information
                auth = get_auth_manager()
                user = auth.get_current_user()
                
                # Prepare claims data for email
                claims_data = []
                for _, claim in selected_df.iterrows():
                    claim_record = {
                        'tracking_number': claim['Tracking Number'],
                        'error_type': claim['Error Type'],
                        'refund_estimate': claim['Refund Estimate'],
                        'submission_method': claim_method,
                        'submitted_at': submitted_time,
                        'status': 'Submitted',
                        'carrier': claim['Carrier']
                    }
                    st.session_state.submitted_claims.append(claim_record)
                    claims_data.append(claim_record)
                
                # Send email to RateWise team
                email_sent = False
                try:
                    if 'SENDGRID_API_KEY' in os.environ:
                        email_manager = EmailManager()
                        email_sent = email_manager.send_claim_submission_email(
                            claims_data=claims_data,
                            user_name=user.get('name', 'Unknown User'),
                            company_name=user.get('company_name', 'N/A'),
                            submission_method=claim_method
                        )
                except Exception as e:
                    print(f"Email sending error: {e}")
                    st.error(f"""
                     **Email Notification Failed**
                    
                    Your claims have been logged locally, but we couldn't send an automatic notification 
                    to the RateWise team due to an email service issue.
                    
                    **What this means:**
                    - Your claims are still recorded in the system
                    - Please contact the RateWise team directly at Audit@ratewiseconsulting.com
                    - Include your claim details in your email
                    
                    **Error details:** {str(e)}
                    """)
                
                # Success message
                if email_sent:
                    st.success(f"""
                     **Claims Successfully Submitted!**
                    
                    - **Number of Claims:** {total_selected}
                    - **Total Recovery Amount:** {format_currency(total_recovery)}
                    - **Submission Method:** {claim_method}
                    - **Submitted At:** {submitted_time}
                    
                     **RateWise team has been automatically notified** and will begin processing your claims immediately.
                    You will receive updates as your claims progress through the recovery process.
                    """)
                else:
                    # Check if we have SendGrid configured
                    if 'SENDGRID_API_KEY' not in os.environ:
                        st.warning(f"""
                         **Claims Logged - Manual Follow-up Required**
                        
                        - **Number of Claims:** {total_selected}
                        - **Total Recovery Amount:** {format_currency(total_recovery)}
                        - **Submission Method:** {claim_method}
                        - **Submitted At:** {submitted_time}
                        
                         **Email service not configured.** Please contact the RateWise team directly at 
                        **Audit@ratewiseconsulting.com** with your claim details.
                        """)
                    else:
                        st.error(f"""
                         **Claims Logged - Email Failed**
                        
                        - **Number of Claims:** {total_selected}
                        - **Total Recovery Amount:** {format_currency(total_recovery)}
                        - **Submission Method:** {claim_method}
                        - **Submitted At:** {submitted_time}
                        
                         **Automatic notification failed.** Your claims are recorded, but please also 
                        contact **Audit@ratewiseconsulting.com** directly to ensure prompt processing.
                        """)
                
                # Update claim status in actionable_errors
                st.session_state.actionable_errors.loc[st.session_state.selected_claims, 'Claim Status'] = 'Submitted'
                
                # Clear selected claims after successful submission
                st.session_state.selected_claims = []
                
                st.rerun()
        
        else:
            st.info(" Select claims above to submit them for recovery.")
    
    else:
        st.warning("No claims match your filter criteria.")
    
    # Claims status tracking section
    if st.session_state.submitted_claims:
        st.markdown("---")
        st.subheader(" Claims Status Tracker")
        
        # Create DataFrame from submitted claims
        claims_df = pd.DataFrame(st.session_state.submitted_claims)
        
        # Status summary
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            submitted_count = len(claims_df[claims_df['status'] == 'Submitted'])
            st.metric("Submitted", submitted_count)
        
        with col2:
            # Simulate some progress (randomly assign some as "In Progress")
            in_progress_count = max(0, len(claims_df) - submitted_count - 2)
            st.metric("In Progress", in_progress_count)
        
        with col3:
            # Simulate some approvals (randomly assign some as "Approved")
            approved_count = min(2, len(claims_df))
            st.metric("Approved", approved_count)
        
        with col4:
            rejected_count = 0  # Start with 0 rejections
            st.metric("Rejected", rejected_count)
        
        # Detailed status table
        st.subheader(" Detailed Status")
        
        # Format the claims data for display
        display_claims = claims_df.copy()
        display_claims['Refund Amount'] = display_claims['refund_estimate'].apply(format_currency)
        display_claims['Submitted Date'] = pd.to_datetime(display_claims['submitted_at']).dt.strftime('%Y-%m-%d %H:%M')
        
        # Display with proper column names
        display_columns = {
            'tracking_number': 'Tracking Number',
            'error_type': 'Error Type', 
            'carrier': 'Carrier',
            'Refund Amount': 'Refund Amount',
            'status': 'Status',
            'Submitted Date': 'Submitted Date'
        }
        
        st.dataframe(
            display_claims[list(display_columns.keys())].rename(columns=display_columns),
            use_container_width=True
        )

def dashboard_page():
    """Display audit results dashboard"""
    st.header("Audit Dashboard")
    
    if st.session_state.audit_results is None:
        st.warning("No audit results available. Please upload and audit data first.")
        return
    
    audit_results = st.session_state.audit_results
    
    # Savings Summary
    st.subheader("Savings Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class="metric-card">
            <h3>Total Charges Audited</h3>
            <h2 style="color: #1F497D;">""" + format_currency(audit_results['summary']['total_charges']) + """</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="metric-card">
            <h3>Potential Savings</h3>
            <h2 style="color: #FFA947;">""" + format_currency(audit_results['summary']['total_savings']) + """</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        savings_rate = (audit_results['summary']['total_savings'] / audit_results['summary']['total_charges'] * 100) if audit_results['summary']['total_charges'] > 0 else 0
        st.markdown("""
        <div class="metric-card">
            <h3>Savings Rate</h3>
            <h2 style="color: #1F497D;">""" + f"{savings_rate:.1f}%" + """</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown("""
        <div class="metric-card">
            <h3>Shipments with Issues</h3>
            <h2 style="color: #FFA947;">""" + str(audit_results['summary']['affected_shipments']) + """</h2>
        </div>
        """, unsafe_allow_html=True)
    
    # Visualizations
    viz_manager = VisualizationManager()
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Error Types Distribution")
        error_chart = viz_manager.create_error_distribution_chart(audit_results['findings'])
        st.plotly_chart(error_chart, use_container_width=True)
    
    with col2:
        st.subheader("Savings by Category")
        savings_chart = viz_manager.create_savings_by_category_chart(audit_results['findings'])
        st.plotly_chart(savings_chart, use_container_width=True)
    
    # Timeline chart
    st.subheader("Overcharges Timeline")
    timeline_chart = viz_manager.create_timeline_chart(audit_results['findings'])
    st.plotly_chart(timeline_chart, use_container_width=True)
    
    # Detailed findings table
    st.subheader("Detailed Audit Findings")
    
    if not audit_results['findings'].empty:
        # Advanced filter options
        with st.expander(" Advanced Filters", expanded=False):
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                error_types = ['All'] + list(audit_results['findings']['Error Type'].unique())
                selected_error = st.selectbox("Error Type", error_types)
            
            with col2:
                carriers = ['All'] + list(audit_results['findings']['Carrier'].unique()) if 'Carrier' in audit_results['findings'].columns else ['All']
                selected_carrier = st.selectbox("Carrier", carriers)
            
            with col3:
                service_types = ['All'] + list(audit_results['findings']['Service Type'].unique()) if 'Service Type' in audit_results['findings'].columns else ['All']
                selected_service = st.selectbox("Service Type", service_types)
            
            with col4:
                min_savings = st.number_input("Min Refund ($)", min_value=0.0, value=0.0)
                max_savings = st.number_input("Max Refund ($)", min_value=0.0, value=10000.0)
            
            # Date range filter
            col1, col2, col3 = st.columns(3)
            with col1:
                if 'Date' in audit_results['findings'].columns:
                    dates = pd.to_datetime(audit_results['findings']['Date'], errors='coerce')
                    min_date = dates.min().date() if not dates.isna().all() else datetime.now().date() - timedelta(days=365)
                    max_date = dates.max().date() if not dates.isna().all() else datetime.now().date()
                    
                    start_date = st.date_input("Start Date", value=min_date, min_value=min_date, max_value=max_date)
                    end_date = st.date_input("End Date", value=max_date, min_value=min_date, max_value=max_date)
            
            # Text search
            with col2:
                search_text = st.text_input("Search Tracking Numbers", placeholder="Enter tracking number...")
            
            with col3:
                dispute_reason_search = st.text_input("Search Dispute Reasons", placeholder="Enter keywords...")
        
        # Sort options
        col1, col2 = st.columns(2)
        with col1:
            sort_by = st.selectbox("Sort By", ["Date", "Refund Estimate", "Error Type", "Carrier", "Tracking Number"])
        with col2:
            sort_order = st.selectbox("Sort Order", ["Descending", "Ascending"])
        
        # Apply filters
        filtered_findings = audit_results['findings'].copy()
        
        # Error type filter
        if selected_error != 'All':
            filtered_findings = filtered_findings[filtered_findings['Error Type'] == selected_error]
        
        # Carrier filter
        if selected_carrier != 'All' and 'Carrier' in filtered_findings.columns:
            filtered_findings = filtered_findings[filtered_findings['Carrier'] == selected_carrier]
        
        # Service type filter
        if 'selected_service' in locals() and selected_service != 'All' and 'Service Type' in filtered_findings.columns:
            filtered_findings = filtered_findings[filtered_findings['Service Type'] == selected_service]
        
        # Refund amount filters
        if min_savings > 0:
            filtered_findings = filtered_findings[filtered_findings['Refund Estimate'] >= min_savings]
        
        if 'max_savings' in locals() and max_savings < 10000:
            filtered_findings = filtered_findings[filtered_findings['Refund Estimate'] <= max_savings]
        
        # Date range filter
        if 'start_date' in locals() and 'end_date' in locals() and 'Date' in filtered_findings.columns:
            dates = pd.to_datetime(filtered_findings['Date'], errors='coerce')
            filtered_findings = filtered_findings[
                (dates >= pd.to_datetime(start_date)) & 
                (dates <= pd.to_datetime(end_date))
            ]
        
        # Text search filters
        if 'search_text' in locals() and search_text and 'Tracking Number' in filtered_findings.columns:
            filtered_findings = filtered_findings[
                filtered_findings['Tracking Number'].astype(str).str.contains(search_text, case=False, na=False)
            ]
        
        if 'dispute_reason_search' in locals() and dispute_reason_search and 'Dispute Reason' in filtered_findings.columns:
            filtered_findings = filtered_findings[
                filtered_findings['Dispute Reason'].astype(str).str.contains(dispute_reason_search, case=False, na=False)
            ]
        
        # Sort the results
        if not filtered_findings.empty and sort_by in filtered_findings.columns:
            ascending = sort_order == "Ascending"
            if sort_by == "Refund Estimate":
                filtered_findings = filtered_findings.sort_values(by=sort_by, ascending=ascending)
            elif sort_by == "Date":
                filtered_findings['sort_date'] = pd.to_datetime(filtered_findings['Date'], errors='coerce')
                filtered_findings = filtered_findings.sort_values(by='sort_date', ascending=ascending)
                filtered_findings = filtered_findings.drop('sort_date', axis=1)
            else:
                filtered_findings = filtered_findings.sort_values(by=sort_by, ascending=ascending)
        
        # Display filtered results
        st.dataframe(
            filtered_findings,
            use_container_width=True,
            column_config={
                "Refund Estimate": st.column_config.NumberColumn(
                    "Refund Estimate",
                    format="$%.2f"
                ),
                "Date": st.column_config.DateColumn(
                    "Date",
                    format="MM/DD/YYYY"
                )
            }
        )
        
        st.info(f"Showing {len(filtered_findings)} of {len(audit_results['findings'])} findings")
    
    else:
        st.success("🎉 No issues found in your shipment data!")

def generate_report_page():
    """Generate and download PDF dispute report"""
    st.header("📄 Generate Dispute Report")
    
    if st.session_state.audit_results is None:
        st.warning("No audit results available. Please upload and audit data first.")
        return
    
    audit_results = st.session_state.audit_results
    
    # Report configuration
    st.subheader(" Report Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        company_name = st.text_input("Company Name", value="Your Company")
        report_date = st.date_input("Report Date", value=datetime.now().date())
    
    with col2:
        include_summary = st.checkbox("Include Executive Summary", value=True)
        group_by_carrier = st.checkbox("Group by Carrier", value=True)
    
    # Generate report button
    if st.button("📄 Generate PDF Report", type="primary"):
        with st.spinner("Generating PDF dispute report..."):
            try:
                pdf_generator = PDFGenerator()
                pdf_buffer = pdf_generator.generate_dispute_report(
                    audit_results,
                    company_name=company_name,
                    report_date=datetime.combine(report_date, datetime.min.time()),
                    include_summary=include_summary,
                    group_by_carrier=group_by_carrier
                )
                
                # Download button
                st.download_button(
                    label="📥 Download Dispute Report",
                    data=pdf_buffer.getvalue(),
                    file_name=f"RateWise_Dispute_Report_{datetime.now().strftime('%Y%m%d')}.pdf",
                    mime="application/pdf"
                )
                
                st.success(" PDF report generated successfully!")
                
            except Exception as e:
                st.error(f" Error generating PDF: {str(e)}")
    
    # Preview report summary
    if not audit_results['findings'].empty:
        st.subheader(" Report Preview")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Report Summary:**")
            st.write(f"• Total Findings: {len(audit_results['findings'])}")
            st.write(f"• Total Potential Savings: {format_currency(audit_results['summary']['total_savings'])}")
            st.write(f"• Report Date: {report_date}")
            
        with col2:
            st.markdown("**Error Breakdown:**")
            error_counts = audit_results['findings']['Error Type'].value_counts()
            for error_type, count in error_counts.items():
                st.write(f"• {error_type}: {count}")

def export_data_page():
    """Export audit results to CSV"""
    st.header(" Export Data")
    
    if st.session_state.audit_results is None:
        st.warning("No audit results available. Please upload and audit data first.")
        return
    
    audit_results = st.session_state.audit_results
    
    st.subheader("💾 Export Options")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Available Exports:**")
        st.write("• Audit Findings (CSV)")
        st.write("• Summary Report (CSV)")
        st.write("• Raw Data with Flags (CSV)")
    
    with col2:
        export_format = st.selectbox("Export Format", ["CSV", "Excel"])
        include_raw_data = st.checkbox("Include Original Data", value=True)
    
    # Export buttons
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button(" Export Findings"):
            csv_buffer = io.StringIO()
            audit_results['findings'].to_csv(csv_buffer, index=False)
            
            st.download_button(
                label="📥 Download Findings CSV",
                data=csv_buffer.getvalue(),
                file_name=f"ratewise_findings_{datetime.now().strftime('%Y%m%d')}.csv",
                mime="text/csv"
            )
    
    with col2:
        if st.button(" Export Summary"):
            summary_df = pd.DataFrame([audit_results['summary']])
            csv_buffer = io.StringIO()
            summary_df.to_csv(csv_buffer, index=False)
            
            st.download_button(
                label="📥 Download Summary CSV",
                data=csv_buffer.getvalue(),
                file_name=f"ratewise_summary_{datetime.now().strftime('%Y%m%d')}.csv",
                mime="text/csv"
            )
    
    with col3:
        if st.button(" Export All Data") and include_raw_data:
            if st.session_state.uploaded_data is not None:
                csv_buffer = io.StringIO()
                st.session_state.uploaded_data.to_csv(csv_buffer, index=False)
                
                st.download_button(
                    label="📥 Download Raw Data CSV",
                    data=csv_buffer.getvalue(),
                    file_name=f"ratewise_raw_data_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )

def audit_history_page():
    """Display audit history and trends"""
    st.header(" Audit History")
    
    auth = get_auth_manager()
    user = auth.get_current_user()
    
    # Check if in demo mode
    if st.session_state.get('demo_mode', False):
        st.warning("Running in demo mode - audit history is not available.")
        st.info("To access audit history, please ensure database connectivity and restart the application.")
        return
    
    try:
        db = get_db_manager()
        # Get user statistics
        stats = db.get_user_statistics(user['id'])
    except Exception as e:
        st.error(" Unable to connect to database to retrieve history.")
        st.info(" You can still use the current session features in the Dashboard and Generate Report pages.")
        return
    
    # Display overall statistics
    st.subheader(" Your RateWise Statistics")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Audits", stats['total_audits'])
    
    with col2:
        st.metric("Charges Audited", format_currency(stats['total_charges_audited']))
    
    with col3:
        st.metric("Savings Identified", format_currency(stats['total_savings_identified']))
    
    with col4:
        avg_savings = (stats['total_savings_identified'] / stats['total_charges_audited'] * 100) if stats['total_charges_audited'] > 0 else 0
        st.metric("Avg Savings Rate", f"{avg_savings:.1f}%")
    
    st.markdown("---")
    
    # Get audit history
    audit_history = db.get_user_audit_history(user['id'])
    
    if not audit_history:
        st.info(" No audit history yet. Upload your first shipment data to get started!")
        return
    
    st.subheader(" Recent Audits")
    
    # Create history table
    history_data = []
    for session in audit_history:
        history_data.append({
            'Date': session.created_at.strftime('%Y-%m-%d %H:%M'),
            'Filename': session.filename,
            'Total Charges': f"${session.total_charges:,.2f}",
            'Savings Found': f"${session.total_savings:,.2f}",
            'Savings Rate': f"{session.savings_rate:.1f}%",
            'Affected Shipments': session.affected_shipments,
            'Total Shipments': session.total_shipments,
            'Session ID': session.id
        })
    
    if history_data:
        import pandas as pd
        history_df = pd.DataFrame(history_data)
        
        # Display table with selection
        selected_indices = st.dataframe(
            history_df.drop('Session ID', axis=1),
            use_container_width=True,
            hide_index=True,
            on_select="rerun",
            selection_mode="single-row"
        )
        
        # Show details for selected audit
        if hasattr(selected_indices, 'selection') and selected_indices.selection.rows:
            selected_idx = selected_indices.selection.rows[0]
            selected_session_id = history_data[selected_idx]['Session ID']
            
            st.subheader(" Audit Details")
            
            # Get detailed audit session
            session_details = db.get_audit_session_details(selected_session_id, user['id'])
            
            if session_details:
                session = session_details['session']
                findings = session_details['findings']
                
                # Display session summary
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown(f"**Audit Date:** {session.created_at.strftime('%Y-%m-%d %H:%M')}")
                    st.markdown(f"**Filename:** {session.filename}")
                    st.markdown(f"**Total Charges:** {format_currency(session.total_charges)}")
                    st.markdown(f"**Total Savings:** {format_currency(session.total_savings)}")
                
                with col2:
                    st.markdown(f"**Savings Rate:** {session.savings_rate:.1f}%")
                    st.markdown(f"**Total Shipments:** {session.total_shipments:,}")
                    st.markdown(f"**Affected Shipments:** {session.affected_shipments:,}")
                    st.markdown(f"**Error Rate:** {(session.affected_shipments/session.total_shipments*100) if session.total_shipments > 0 else 0:.1f}%")
                
                # Display findings
                if findings:
                    st.subheader(" Audit Findings")
                    
                    findings_data = []
                    for finding in findings:
                        findings_data.append({
                            'Error Type': finding.error_type,
                            'Tracking Number': finding.tracking_number,
                            'Date': finding.shipment_date.strftime('%Y-%m-%d') if finding.shipment_date else '',
                            'Carrier': finding.carrier,
                            'Service Type': finding.service_type,
                            'Dispute Reason': finding.dispute_reason,
                            'Refund Estimate': f"${finding.refund_estimate:.2f}",
                            'Notes': finding.notes
                        })
                    
                    findings_df = pd.DataFrame(findings_data)
                    st.dataframe(findings_df, use_container_width=True, hide_index=True)
                    
                    # Option to regenerate report for this session
                    if st.button("📄 Generate Report for This Audit", key=f"report_{selected_session_id}"):
                        # Convert findings back to the format expected by PDF generator
                        findings_for_pdf = pd.DataFrame([{
                            'Error Type': f.error_type,
                            'Tracking Number': f.tracking_number,
                            'Date': f.shipment_date.strftime('%Y-%m-%d') if f.shipment_date else '',
                            'Carrier': f.carrier,
                            'Service Type': f.service_type,
                            'Dispute Reason': f.dispute_reason,
                            'Refund Estimate': f.refund_estimate,
                            'Notes': f.notes
                        } for f in findings])
                        
                        audit_results_for_pdf = {
                            'findings': findings_for_pdf,
                            'summary': {
                                'total_charges': session.total_charges,
                                'total_savings': session.total_savings,
                                'affected_shipments': session.affected_shipments,
                                'total_shipments': session.total_shipments,
                                'savings_rate': session.savings_rate
                            }
                        }
                        
                        try:
                            pdf_generator = PDFGenerator()
                            pdf_buffer = pdf_generator.generate_dispute_report(
                                audit_results_for_pdf,
                                company_name=user['company_name'] or "Your Company",
                                report_date=datetime.combine(session.created_at.date(), datetime.min.time()),
                                include_summary=True,
                                group_by_carrier=True
                            )
                            
                            st.download_button(
                                label="📥 Download Historical Report",
                                data=pdf_buffer.getvalue(),
                                file_name=f"RateWise_Historical_Report_{session.created_at.strftime('%Y%m%d')}.pdf",
                                mime="application/pdf"
                            )
                            
                        except Exception as e:
                            st.error(f" Error generating historical report: {str(e)}")
                else:
                    st.info("No specific findings recorded for this audit session.")
    
    # Load previous audit into current session
    if st.button("🔄 Load Selected Audit into Current Session"):
        if hasattr(selected_indices, 'selection') and selected_indices.selection.rows:
            selected_idx = selected_indices.selection.rows[0]
            selected_session_id = history_data[selected_idx]['Session ID']
            
            session_details = db.get_audit_session_details(selected_session_id, user['id'])
            
            if session_details:
                findings = session_details['findings']
                session = session_details['session']
                
                # Convert back to audit results format
                findings_df = pd.DataFrame([{
                    'Error Type': f.error_type,
                    'Tracking Number': f.tracking_number,
                    'Date': f.shipment_date.strftime('%Y-%m-%d') if f.shipment_date else '',
                    'Carrier': f.carrier,
                    'Service Type': f.service_type,
                    'Dispute Reason': f.dispute_reason,
                    'Refund Estimate': f.refund_estimate,
                    'Notes': f.notes
                } for f in findings])
                
                audit_results = {
                    'findings': findings_df,
                    'summary': {
                        'total_charges': session.total_charges,
                        'total_savings': session.total_savings,
                        'affected_shipments': session.affected_shipments,
                        'total_shipments': session.total_shipments,
                        'savings_rate': session.savings_rate
                    }
                }
                
                st.session_state.audit_results = audit_results
                st.success(" Audit loaded! You can now view it in the Dashboard or generate reports.")
        else:
            st.warning("Please select an audit session first.")

def quickbooks_export_page():
    """QuickBooks integration and export functionality"""
    st.header(" QuickBooks Export")
    
    # Check if we have audit results
    if 'audit_results' not in st.session_state or st.session_state.audit_results is None:
        st.warning("No audit results available. Please run an audit first.")
        st.info(" Go to 'Upload & Audit' to process your shipment data, then return here to export to QuickBooks.")
        return
    
    audit_results = st.session_state.audit_results
    findings_df = audit_results.get('findings', pd.DataFrame())
    
    if findings_df.empty:
        st.warning(" No audit findings to export.")
        return
    
    # Initialize QuickBooks exporter
    qb_exporter = QuickBooksExporter()
    
    st.markdown("""
    <div style="background: linear-gradient(90deg, #1F497D 0%, #FFA947 100%); color: white; padding: 1rem; border-radius: 10px; margin-bottom: 2rem;">
        <h3 style="color: white; margin: 0;">🔗 QuickBooks Online Integration</h3>
        <p style="margin: 0.5rem 0 0 0;">Export your freight audit findings to QuickBooks Online for seamless accounting integration</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Validate export data first
    validation_results = qb_exporter.validate_export_data(findings_df)
    
    # Display validation results
    if not validation_results['is_valid']:
        st.error(" **Data Validation Failed**")
        for error in validation_results['errors']:
            st.error(f"• {error}")
        return
    
    # Show warnings if any
    if validation_results['warnings']:
        st.warning(" **Data Validation Warnings**")
        for warning in validation_results['warnings']:
            st.warning(f"• {warning}")
    
    # Display validation summary
    summary = validation_results['summary']
    if summary:
        st.success(" **Data Validation Passed**")
        with st.expander(" Validation Summary"):
            col1, col2 = st.columns(2)
            with col1:
                st.write(f"**Total Rows:** {summary.get('total_rows', 0)}")
                st.write(f"**Valid Refund Rows:** {summary.get('valid_refund_rows', 0)}")
            with col2:
                st.write(f"**Error Types:** {summary.get('unique_error_types', 0)}")
                st.write(f"**Mapped Types:** {summary.get('mapped_error_types', 0)}")
            
            st.write(f"**Total Refund Amount:** {format_currency(summary.get('total_refund_amount', 0))}")
        
        st.markdown("---")
    
    # Summary of export
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric(
            " Total Findings", 
            len(findings_df),
            help="Number of overcharge findings to export"
        )
    
    with col2:
        total_refunds = findings_df['Refund Estimate'].sum()
        st.metric(
            " Total Refunds", 
            format_currency(total_refunds),
            help="Total refund amount to record in QuickBooks"
        )
    
    with col3:
        error_types = len(findings_df['Error Type'].unique())
        st.metric(
            "🏷️ Error Types", 
            error_types,
            help="Number of different error types found"
        )
    
    st.markdown("---")
    
    # Export options
    st.subheader(" Export Options")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("###  Journal Entries")
        st.write("Export journal entries to record refunds receivable and reduce freight expenses")
        
        if st.button("📥 Generate Journal Entries CSV", type="primary"):
            # Re-validate before generating
            validation_check = qb_exporter.validate_export_data(findings_df)
            if not validation_check['is_valid']:
                st.error(" Cannot generate journal entries due to validation errors")
                return
            
            journal_entries = qb_exporter.generate_journal_entries(findings_df)
            if not journal_entries.empty:
                csv_data = qb_exporter.export_to_csv(journal_entries, "journal_entries")
                st.success(f" Generated {len(journal_entries)} journal entry lines")
                
                st.download_button(
                    label="💾 Download Journal Entries (QBO Format)",
                    data=csv_data,
                    file_name=f"RateWise_Journal_Entries_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv",
                    help="Import this file into QuickBooks Online using Gear > Import Data > Journal Entries"
                )
                
                # Preview the data
                with st.expander("️ Preview Journal Entries (First 10 rows)"):
                    st.dataframe(journal_entries.head(10))
                    if len(journal_entries) > 10:
                        st.info(f"Showing first 10 of {len(journal_entries)} total entries")
            else:
                st.error(" No journal entries could be generated. Check validation warnings above.")
    
    with col2:
        st.markdown("### 🏢 Vendor List")
        st.write("Export carrier information as vendors for easier invoice reconciliation")
        
        if st.button("🚚 Generate Vendor List CSV"):
            vendors = qb_exporter.generate_vendor_export(findings_df)
            if not vendors.empty:
                csv_data = qb_exporter.export_to_csv(vendors, "vendors")
                st.download_button(
                    label="💾 Download Vendor List",
                    data=csv_data,
                    file_name=f"RateWise_Vendors_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv",
                    help="Import these carriers as vendors in QuickBooks"
                )
                
                # Preview the data
                with st.expander("️ Preview Vendor List"):
                    st.dataframe(vendors)
            else:
                st.error("No vendor data available in audit findings")
    
    st.markdown("---")
    
    # Additional exports
    st.subheader("📦 Additional Exports")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🏷️ Items List")
        st.write("Create QuickBooks items for tracking different types of freight refunds")
        
        if st.button("📝 Generate Items List CSV"):
            items = qb_exporter.generate_items_export(findings_df)
            if not items.empty:
                csv_data = qb_exporter.export_to_csv(items, "items")
                st.download_button(
                    label="💾 Download Items List",
                    data=csv_data,
                    file_name=f"RateWise_Items_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv",
                    help="Import these items into QuickBooks for tracking refund types"
                )
                
                # Preview the data
                with st.expander("️ Preview Items List"):
                    st.dataframe(items)
            else:
                st.error("No items could be generated")
    
    with col2:
        st.markdown("###  Summary Report")
        st.write("Generate a comprehensive summary for your accounting records")
        
        if st.button(" Generate Summary"):
            summary = qb_exporter.generate_summary_report(findings_df)
            
            if summary:
                # Display summary
                st.json(summary)
                
                # Create downloadable summary
                summary_df = pd.DataFrame([summary])
                csv_data = qb_exporter.export_to_csv(summary_df, "summary")
                st.download_button(
                    label="💾 Download Summary",
                    data=csv_data,
                    file_name=f"RateWise_Summary_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv",
                    help="Summary report for your records"
                )
            else:
                st.error("Could not generate summary")
    
    st.markdown("---")
    
    # Instructions
    st.subheader("📖 QuickBooks Import Instructions")
    
    with st.expander("📚 Step-by-Step Import Guide", expanded=False):
        instructions = qb_exporter.get_quickbooks_instructions()
        st.markdown(instructions)
    
    # Account mapping configuration
    st.subheader("⚙️ Account Configuration")
    
    with st.expander(" Customize Account Mapping", expanded=False):
        st.write("Configure which QuickBooks accounts to use for different error types:")
        
        error_types = findings_df['Error Type'].unique()
        
        for error_type in error_types:
            st.write(f"**{error_type}**")
            col1, col2, col3 = st.columns(3)
            
            with col1:
                debit_account = st.text_input(
                    f"Debit Account for {error_type}",
                    value="Refunds Receivable",
                    key=f"debit_{error_type}"
                )
            
            with col2:
                credit_account = st.text_input(
                    f"Credit Account for {error_type}",
                    value="Freight Expense", 
                    key=f"credit_{error_type}"
                )
            
            with col3:
                description = st.text_input(
                    f"Description for {error_type}",
                    value=f"{error_type} refund claim",
                    key=f"desc_{error_type}"
                )
            
            # Update mapping if changed
            qb_exporter.update_account_mapping(error_type, debit_account, credit_account, description)

def email_reports_page():
    """Email reporting and automation page"""
    st.header(" Email Reports & Automation")
    
    # Check SendGrid configuration
    sendgrid_configured = 'SENDGRID_API_KEY' in os.environ
    
    if not sendgrid_configured:
        st.error(" **SendGrid Not Configured**")
        st.info("To enable email reporting, you need to configure SendGrid:")
        st.code("SENDGRID_API_KEY=your_api_key_here")
        st.warning("Please ask your administrator to set up the SendGrid API key.")
        
        if st.button(" Request SendGrid Setup"):
            # This would trigger the secret request process
            st.info("📝 SendGrid setup has been requested. You'll be prompted to enter your API key.")
        
        return
    
    auth = get_auth_manager()
    user = auth.get_current_user()
    
    st.markdown("""
    <div style="background: linear-gradient(90deg, #1F497D 0%, #FFA947 100%); color: white; padding: 1rem; border-radius: 10px; margin-bottom: 2rem;">
        <h3 style="color: white; margin: 0;">📬 Automated Email Reporting</h3>
        <p style="margin: 0.5rem 0 0 0;">Stay informed with automated audit completion notifications and scheduled reports</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Test email connection
    try:
        email_manager = EmailManager()
        connection_status = email_manager.test_email_connection()
        if connection_status:
            st.success(" Email service is properly configured and ready to use")
        else:
            st.warning(" Email service configuration may have issues")
    except Exception as e:
        st.error(" Email service configuration error")
        return
    
    # Email Reports Sections
    tab1, tab2, tab3 = st.tabs([" Send Report", "⚙️ Settings", " Templates"])
    
    with tab1:
        st.subheader(" Send Audit Report via Email")
        
        # Check if we have audit results
        if 'audit_results' not in st.session_state or st.session_state.audit_results is None:
            st.warning("No audit results available. Please run an audit first.")
            st.info("Go to 'Upload & Audit' to process your shipment data, then return here to send email reports.")
        else:
            audit_results = st.session_state.audit_results
            findings_df = audit_results.get('findings', pd.DataFrame())
            
            if not findings_df.empty:
                # Email form
                with st.form("send_email_form"):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        recipient_email = st.text_input(
                            " Recipient Email", 
                            value=user.get('email', ''),
                            help="Email address to send the audit report to"
                        )
                        
                        include_pdf = st.checkbox(
                            "📄 Include PDF Report", 
                            value=True,
                            help="Attach a professional PDF audit report"
                        )
                    
                    with col2:
                        additional_recipients = st.text_area(
                            " CC Recipients (Optional)",
                            placeholder="additional@email.com\nanother@email.com",
                            help="Enter additional email addresses, one per line"
                        )
                        
                        custom_subject = st.text_input(
                            "📝 Custom Subject (Optional)",
                            placeholder="Leave empty for default subject"
                        )
                    
                    # Preview email content
                    with st.expander("️ Preview Email Content"):
                        total_savings = audit_results.get('summary', {}).get('total_savings', 0)
                        st.write(f"**Subject:** 🚛 RateWise Audit Complete - {format_currency(total_savings)} in Potential Savings Found!")
                        st.write(f"**Total Findings:** {len(findings_df)}")
                        st.write(f"**Affected Shipments:** {audit_results.get('summary', {}).get('affected_shipments', 0)}")
                        
                        if findings_df is not None and not findings_df.empty:
                            error_summary = findings_df['Error Type'].value_counts()
                            st.write("**Error Types Found:**")
                            for error_type, count in error_summary.head(5).items():
                                st.write(f"- {error_type}: {count} occurrences")
                    
                    submitted = st.form_submit_button(" Send Email Report", type="primary")
                    
                    if submitted:
                        if not recipient_email:
                            st.error("Please enter a recipient email address.")
                        else:
                            try:
                                with st.spinner("Sending email..."):
                                    # Generate PDF if requested
                                    pdf_data = None
                                    if include_pdf:
                                        pdf_gen = PDFGenerator()
                                        pdf_data = pdf_gen.generate_audit_report(
                                            audit_results,
                                            user.get('name', 'User'),
                                            user.get('company_name', 'Your Company')
                                        )
                                    
                                    # Send email
                                    success = email_manager.send_audit_complete_email(
                                        to_email=recipient_email,
                                        audit_results=audit_results,
                                        findings_df=findings_df,
                                        user_name=user.get('name', 'User'),
                                        company_name=user.get('company_name'),
                                        pdf_attachment=pdf_data
                                    )
                                    
                                    if success:
                                        st.success(" Email sent successfully!")
                                        st.balloons()
                                    else:
                                        st.error(" Failed to send email. Please try again or check your configuration.")
                            
                            except Exception as e:
                                st.error(f" Error sending email: {str(e)}")
            else:
                st.info("No audit findings available to email.")
    
    with tab2:
        st.subheader("⚙️ Email Settings")
        
        st.write("**Current Configuration:**")
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric(" Email Service", "SendGrid", help="Email delivery service")
            st.metric("👤 Default Sender", "noreply@ratewise.com", help="From email address")
        
        with col2:
            st.metric(" Status", "Active", help="Email service status")
            st.metric(" Templates", "3 Available", help="Number of email templates")
        
        st.markdown("---")
        
        # Future automation settings
        st.subheader("🔄 Automation Settings (Coming Soon)")
        
        with st.expander("📅 Scheduled Reports"):
            st.write("Configure automatic weekly or monthly reports:")
            
            col1, col2 = st.columns(2)
            with col1:
                weekly_reports = st.checkbox("Weekly Summary Reports", disabled=True)
                weekly_day = st.selectbox("Send on", ["Monday", "Friday"], disabled=True)
            
            with col2:
                monthly_reports = st.checkbox("Monthly Performance Reports", disabled=True)
                monthly_day = st.number_input("Day of Month", min_value=1, max_value=28, value=1, disabled=True)
            
            st.info(" Scheduled reporting will be available in a future update.")
    
    with tab3:
        st.subheader(" Email Templates")
        
        template_options = st.selectbox(
            "Select Template to Preview",
            ["Audit Complete", "Weekly Summary", "Monthly Report"]
        )
        
        if template_options == "Audit Complete":
            st.markdown("**Subject:** 🚛 RateWise Audit Complete - [Total Savings] in Potential Savings Found!")
            st.markdown("**Purpose:** Sent immediately after an audit is completed with detailed findings")
            
            with st.expander("📝 Template Content Preview"):
                st.markdown("""
                **Email includes:**
                - Personalized greeting with user and company name
                - Total savings amount and key metrics
                - Summary of findings by error type
                - Next steps and recommendations
                - Optional PDF attachment with full report
                - Professional RateWise branding
                """)
        
        elif template_options == "Weekly Summary":
            st.markdown("**Subject:**  RateWise Weekly Summary - [Weekly Savings] This Week")
            st.markdown("**Purpose:** Weekly performance summary (planned feature)")
            
            with st.expander("📝 Template Content Preview"):
                st.markdown("""
                **Email includes:**
                - Week's total savings identified
                - Number of audits completed
                - Billing errors found
                - Performance trends
                - Quick access links to dashboard
                """)
        
        elif template_options == "Monthly Report":
            st.markdown("**Subject:**  RateWise Monthly Report - [Monthly Savings] in Savings Identified")  
            st.markdown("**Purpose:** Comprehensive monthly analysis (planned feature)")
            
            with st.expander("📝 Template Content Preview"):
                st.markdown("""
                **Email includes:**
                - Monthly performance metrics
                - Top error types and problematic carriers
                - Savings trends and insights  
                - Recommendations for improvement
                - Executive summary format
                """)
        
        st.markdown("---")
        st.info(" All templates use professional HTML formatting with RateWise branding and are optimized for both desktop and mobile viewing.")

def contract_review_page():
    """Contract Review and Negotiation Strategy page"""
    st.header("📄 Freight Contract Review & Negotiation Strategy")
    
    auth = get_auth_manager()
    user = auth.get_current_user()
    
    st.markdown("""
    <div style="background: linear-gradient(90deg, #1F497D 0%, #FFA947 100%); color: white; padding: 1.5rem; border-radius: 10px; margin-bottom: 2rem;">
        <h3 style="color: white; margin: 0;"> Contract Intelligence Platform</h3>
        <p style="margin: 0.5rem 0 0 0;">Upload your carrier contract to receive a comprehensive analysis, industry benchmark comparison, and custom negotiation strategy</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Create tabs for different sections
    tab1, tab2, tab3, tab4 = st.tabs([" Upload Contract", " Analysis Results", " Strategy", " History"])
    
    with tab1:
        st.subheader(" Upload Carrier Contract")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            # File upload
            uploaded_file = st.file_uploader(
                "Choose your contract file",
                type=['pdf', 'xlsx', 'xls', 'csv'],
                help="Upload your carrier contract, rate sheet, or master agreement"
            )
            
            if uploaded_file:
                # Contract information form
                with st.form("contract_info_form"):
                    st.write("**Contract Information**")
                    
                    col_a, col_b = st.columns(2)
                    with col_a:
                        contract_name = st.text_input(
                            "Contract Name*", 
                            value=uploaded_file.name.split('.')[0],
                            help="A name to identify this contract"
                        )
                        
                        carrier = st.selectbox(
                            "Carrier*",
                            ["FedEx", "UPS", "DHL", "USPS", "Other"],
                            help="Select your carrier"
                        )
                    
                    with col_b:
                        contract_type = st.selectbox(
                            "Contract Type",
                            ["Rate Sheet", "Master Agreement", "Amendment", "Other"],
                            help="Type of contract document"
                        )
                        
                        annual_spend = st.number_input(
                            "Estimated Annual Spend ($)",
                            min_value=0,
                            value=100000,
                            step=10000,
                            help="Your estimated annual shipping spend with this carrier"
                        )
                    
                    submitted = st.form_submit_button(" Analyze Contract", type="primary")
                    
                    if submitted and uploaded_file and contract_name and carrier:
                        try:
                            with st.spinner(" Analyzing your contract... This may take a few minutes."):
                                # Import contract analysis modules
                                from contract_parser import get_contract_parser
                                from contract_benchmarks import get_benchmark_engine
                                from contract_strategy_generator import get_strategy_generator
                                
                                # Parse the contract
                                parser = get_contract_parser()
                                file_extension = uploaded_file.name.split('.')[-1].lower()
                                contract_terms = parser.parse_contract_file(
                                    uploaded_file.getvalue(),
                                    file_extension,
                                    uploaded_file.name
                                )
                                
                                # Get industry benchmarks
                                benchmark_engine = get_benchmark_engine()
                                benchmark = benchmark_engine.get_benchmark_for_company(
                                    carrier, annual_spend
                                )
                                
                                # Convert contract terms to dict for comparison
                                terms_dict = {
                                    'base_discount_pct': contract_terms.base_discount_pct,
                                    'dim_divisor': contract_terms.dim_divisor,
                                    'fuel_surcharge_pct': contract_terms.fuel_surcharge_pct,
                                    'residential_surcharge': contract_terms.residential_surcharge,
                                    'delivery_area_surcharge': contract_terms.delivery_area_surcharge
                                }
                                
                                # Compare to benchmarks
                                comparison_results = benchmark_engine.compare_contract_to_benchmark(
                                    terms_dict, benchmark
                                )
                                
                                # Calculate health score
                                health_score, health_score_numeric = benchmark_engine.calculate_contract_health_score(
                                    comparison_results
                                )
                                
                                # Calculate savings potential
                                savings_potential = benchmark_engine.estimate_annual_savings_potential(
                                    comparison_results, annual_spend
                                )
                                
                                # Generate recommendations
                                recommendations = benchmark_engine.generate_negotiation_recommendations(
                                    comparison_results, benchmark
                                )
                                
                                # Store results in session state
                                st.session_state.contract_analysis = {
                                    'contract_info': {
                                        'name': contract_name,
                                        'carrier': carrier,
                                        'type': contract_type,
                                        'annual_spend': annual_spend,
                                        'filename': uploaded_file.name
                                    },
                                    'contract_terms': terms_dict,
                                    'extraction_confidence': contract_terms.extraction_confidence,
                                    'benchmark_comparison': comparison_results,
                                    'health_score': health_score,
                                    'health_score_numeric': health_score_numeric,
                                    'savings_potential': savings_potential,
                                    'recommendations': recommendations,
                                    'benchmark_data': benchmark
                                }
                                
                                # Save to database if possible
                                try:
                                    db = get_db_manager()
                                    # Note: Would implement database saving here
                                    st.success(" Contract analysis completed successfully!")
                                except Exception as e:
                                    st.success(" Contract analysis completed! (Results saved locally)")
                                
                                st.info(" Switch to the 'Analysis Results' tab to view your contract evaluation.")
                                
                        except Exception as e:
                            st.error(f" Error analyzing contract: {str(e)}")
                            st.info("Please ensure your file contains contract terms in a readable format.")
                    
                    elif submitted:
                        if not uploaded_file:
                            st.error("Please upload a contract file.")
                        elif not contract_name:
                            st.error("Please enter a contract name.")
                        elif not carrier:
                            st.error("Please select a carrier.")
        
        with col2:
            st.markdown("###  **Supported Formats**")
            st.markdown("""
            - **PDF**: Rate sheets, contracts
            - **Excel**: Pricing tables, rate sheets  
            - **CSV**: Rate data exports
            
            ###  **What We Extract**
            - Base discount percentages
            - DIM weight divisors
            - Fuel surcharge rates
            - Residential delivery fees
            - Extended area surcharges
            - Zone-based pricing
            
            ### ⭐ **What You Get**
            - Contract health score (A-F)
            - Industry benchmark comparison
            - Potential savings analysis
            - Professional negotiation strategy
            - Talking points and recommendations
            """)
    
    with tab2:
        st.subheader(" Contract Analysis Results")
        
        if 'contract_analysis' not in st.session_state:
            st.info(" Please upload and analyze a contract first using the 'Upload Contract' tab.")
        else:
            analysis = st.session_state.contract_analysis
            
            # Contract health score display
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric(
                    "Contract Health Score", 
                    analysis['health_score'],
                    f"{analysis['health_score_numeric']:.1f}/100"
                )
            
            with col2:
                total_savings = analysis['savings_potential'].get('total_annual_savings', 0)
                st.metric(
                    "Savings Potential", 
                    format_currency(total_savings),
                    f"{analysis['savings_potential'].get('savings_percentage', 0):.1f}%"
                )
            
            with col3:
                confidence = analysis.get('extraction_confidence', 0) * 100
                st.metric(
                    "Data Confidence",
                    f"{confidence:.0f}%",
                    help="How confident we are in the extracted contract terms"
                )
            
            with col4:
                improvement_areas = len([r for r in analysis.get('recommendations', []) if r.get('priority') == 'high'])
                st.metric(
                    "High Priority Issues",
                    str(improvement_areas),
                    help="Number of high-priority negotiation opportunities"
                )
            
            st.markdown("---")
            
            # Detailed analysis
            if analysis['benchmark_comparison']:
                st.subheader(" Benchmark Comparison")
                
                # Create comparison table
                comparison_data = []
                for term, data in analysis['benchmark_comparison'].items():
                    term_name = term.replace('_', ' ').title()
                    current = data.get('current', 'N/A')
                    best = data.get('best_in_class', 'N/A')
                    performance = data.get('performance_tier', 'Unknown').title()
                    
                    # Format values based on term type
                    if 'discount' in term or 'surcharge' in term and 'pct' in term:
                        current = f"{current}%" if current != 'N/A' else 'N/A'
                        best = f"{best}%" if best != 'N/A' else 'N/A'
                    elif 'surcharge' in term and isinstance(current, (int, float)):
                        current = f"${current:.2f}" if current != 'N/A' else 'N/A'
                        best = f"${best:.2f}" if best != 'N/A' else 'N/A'
                    
                    comparison_data.append([term_name, str(current), str(best), performance])
                
                comparison_df = pd.DataFrame(
                    comparison_data, 
                    columns=['Contract Term', 'Your Current', 'Industry Best', 'Performance']
                )
                
                st.dataframe(comparison_df, hide_index=True, use_container_width=True)
            
            # Key findings
            st.subheader(" Key Findings")
            
            findings_col1, findings_col2 = st.columns(2)
            
            with findings_col1:
                st.write("**Strengths:**")
                strengths = []
                for term, data in analysis['benchmark_comparison'].items():
                    if data.get('performance_tier') in ['excellent', 'good']:
                        term_name = term.replace('_', ' ').title()
                        strengths.append(f" {term_name} - {data['performance_tier'].title()}")
                
                if strengths:
                    for strength in strengths:
                        st.write(strength)
                else:
                    st.write("No significant strengths identified")
            
            with findings_col2:
                st.write("**Areas for Improvement:**")
                improvements = []
                for term, data in analysis['benchmark_comparison'].items():
                    if data.get('performance_tier') in ['poor', 'fair']:
                        term_name = term.replace('_', ' ').title()
                        improvements.append(f" {term_name} - {data['performance_tier'].title()}")
                
                if improvements:
                    for improvement in improvements:
                        st.write(improvement)
                else:
                    st.write("No major issues identified")
    
    with tab3:
        st.subheader(" Negotiation Strategy")
        
        if 'contract_analysis' not in st.session_state:
            st.info(" Please upload and analyze a contract first using the 'Upload Contract' tab.")
        else:
            analysis = st.session_state.contract_analysis
            
            # Action buttons
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if st.button("📄 Generate Strategy PDF", type="primary"):
                    try:
                        with st.spinner("Generating comprehensive negotiation strategy..."):
                            from contract_strategy_generator import get_strategy_generator
                            
                            strategy_gen = get_strategy_generator()
                            pdf_data = strategy_gen.generate_negotiation_strategy(
                                analysis,
                                user.get('name', 'User'),
                                user.get('company_name', 'Your Company')
                            )
                            
                            st.download_button(
                                label="📥 Download Strategy PDF",
                                data=pdf_data,
                                file_name=f"Contract_Strategy_{analysis['contract_info']['name']}.pdf",
                                mime="application/pdf"
                            )
                            st.success(" Strategy PDF generated successfully!")
                            
                    except Exception as e:
                        st.error(f" Error generating PDF: Please try again.")
            
            with col2:
                if st.button(" Email Strategy", type="secondary"):
                    st.info(" Email functionality will be available in the next update.")
            
            with col3:
                if st.button(" Copy Key Points", type="secondary"):
                    st.info(" Copy functionality will be available in the next update.")
            
            st.markdown("---")
            
            # Display recommendations
            st.subheader(" Negotiation Recommendations")
            
            recommendations = analysis.get('recommendations', [])
            
            if recommendations:
                for i, rec in enumerate(recommendations, 1):
                    priority_emoji = {'high': '🔴', 'medium': '🟡', 'low': '🟢'}.get(rec.get('priority', 'medium'), '🔵')
                    
                    with st.expander(f"{priority_emoji} {rec.get('category', 'Recommendation')} ({rec.get('priority', 'medium').title()} Priority)"):
                        col_a, col_b = st.columns(2)
                        
                        with col_a:
                            st.write(f"**Current:** {rec.get('current', 'N/A')}")
                            st.write(f"**Target:** {rec.get('target', 'N/A')}")
                        
                        with col_b:
                            st.write(f"**Estimated Impact:** {rec.get('estimated_savings', 'TBD')}")
                        
                        st.write(f"**Negotiation Talking Point:**")
                        st.info(rec.get('talking_point', 'Negotiate for better terms'))
                        
                        st.write(f"**Business Justification:**")
                        st.write(rec.get('justification', 'Cost optimization opportunity'))
            else:
                st.info("No specific recommendations available. Your contract terms appear to be competitive.")
    
    with tab4:
        st.subheader(" Contract History & Tracking")
        
        # Placeholder for contract history
        st.info(" Contract history tracking will display your previous contract analyses and performance over time.")
        
        # Sample timeline chart
        st.write("**Contract Performance Timeline** (Sample)")
        
        try:
            from contract_visualization import get_visualization_manager
            viz_manager = get_visualization_manager()
            
            timeline_chart = viz_manager.create_contract_timeline_comparison()
            st.plotly_chart(timeline_chart, use_container_width=True)
            
        except Exception:
            st.info(" Performance charts will be available after analyzing your first contract.")

def ai_freight_advisor_page():
    """RateWise AI Freight Advisor page with usage tracking"""
    from freight_ai_advisor import get_freight_ai_advisor
    
    # Get user info
    auth = get_auth_manager()
    user = auth.get_current_user()
    user_context = {
        'company_name': user.get('company_name', 'Not specified'),
        'email': user.get('email', 'Not specified')
    }
    
    # Initialize the advisor
    advisor = get_freight_ai_advisor()
    
    # Custom CSS for modern, responsive design
    st.markdown("""
    <style>
    .advisor-header {
        background: linear-gradient(135deg, #1F497D 0%, #FFA947 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        text-align: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .faq-container {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 1rem;
        margin: 1rem 0;
    }
    .usage-counter {
        background: #fff3cd;
        border: 1px solid #ffeaa7;
        border-radius: 8px;
        padding: 1rem;
        text-align: center;
        margin-top: 2rem;
        font-weight: bold;
    }
    .qa-item {
        background: white;
        border-left: 4px solid #FFA947;
        margin: 0.5rem 0;
        border-radius: 5px;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Header without truck logo
    st.markdown("""
    <div class="advisor-header">
        <h1>RateWise AI Freight Advisor</h1>
        <p>Your smart freight auditing assistant for uncovering savings and optimizing shipping costs</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Get current usage
    current_usage = advisor.get_user_prompt_usage(user['id'])
    
    # Create tabs
    tab1, tab2 = st.tabs(["📚 Common Freight Q&As", "🤖 Custom AI Questions"])
    
    with tab1:
        st.subheader(" Frequently Asked Freight Questions")
        st.markdown("*Click any question below for an instant expert answer (no usage limit):*")
        
        # Display pre-loaded Q&As in collapsible format
        for i, qa in enumerate(advisor.common_qas):
            with st.expander(f"❓ {qa['question']}", expanded=False):
                st.markdown(f"**Answer:** {qa['answer']}")
                
                # Add relevant tips or follow-ups for key topics
                if "demand charges" in qa['question'].lower():
                    st.info(" **Pro Tip:** Keep delivery confirmations and photos of correct addresses to dispute invalid demand charges.")
                elif "dimensional weight" in qa['question'].lower():
                    st.info(" **Pro Tip:** Use the formula (L×W×H)÷139 to calculate dimensional weight before shipping.")
                elif "negotiate" in qa['question'].lower():
                    st.info(" **Pro Tip:** Prepare shipping volume data and competitor quotes before negotiation calls.")
    
    with tab2:
        st.subheader("🤖 Ask Custom AI Questions")
        st.markdown(f"Get personalized advice on shipment auditing, contract benchmarking, and negotiation strategy.")
        
        # Show usage warning if near limit
        if current_usage >= 20:
            st.warning(f" You've used {current_usage} of 25 AI prompts this month. {25 - current_usage} remaining.")
        elif current_usage >= 25:
            st.error(" You've reached your 25 AI interactions this month. Upgrade your plan or wait until next month to unlock more questions.")
        
        # Custom question input
        question = st.text_area(
            "Ask your freight-related question:",
            placeholder="e.g., How can I dispute these specific charges on my FedEx invoice?",
            height=120,
            disabled=(current_usage >= 25)
        )
        
        col1, col2 = st.columns([2, 3])
        with col1:
            if st.button(" Get AI Answer", type="primary", disabled=(current_usage >= 25 or not question.strip())):
                if question.strip():
                    with st.spinner("Getting personalized freight advice..."):
                        response = advisor.ask_custom_freight_question(
                            question, 
                            user['id'], 
                            user_context
                        )
                        
                        # Display the response
                        st.markdown("###  AI Expert Response")
                        st.markdown(response)
                        
                        # Update usage counter
                        current_usage = advisor.get_user_prompt_usage(user['id'])
        
        with col2:
            st.markdown("""
            **Suggested topics:**
            - Disputing specific charges
            - Contract negotiation strategies  
            - Invoice error patterns
            - Packaging optimization
            """)
    
    # Usage counter at bottom
    st.markdown(f"""
    <div class="usage-counter">
         You have used <strong>{current_usage} of 25</strong> Freight AI Prompts this month
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar with advisor info
    with st.sidebar:
        st.markdown("### 🚛 RateWise AI Advisor")
        st.success(f"""
        **Current Usage:** {current_usage}/25 prompts
        **Resets:** 1st of every month
        """)
        
        st.info("""
        **Expert in:**
        - Shipment auditing
        - Invoice overcharges  
        - Contract benchmarking
        - Negotiation strategy
        - Dimensional weight optimization
        - Zone assignments
        """)
        
        if current_usage >= 20:
            st.warning(" **Tip:** Use the Common Q&As tab for unlimited freight guidance!")

if __name__ == "__main__":
    main()
