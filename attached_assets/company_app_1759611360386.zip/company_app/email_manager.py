"""
Email Manager Module for RateWise
Handles automated email reporting and notifications using SendGrid
"""

import os
import sys
import base64
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import pandas as pd
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Attachment, FileContent, FileName, FileType, Disposition

class EmailManager:
    """Manages email notifications and automated reports for RateWise"""
    
    def __init__(self):
        self.sendgrid_key = os.environ.get('SENDGRID_API_KEY')
        if not self.sendgrid_key:
            raise ValueError("SENDGRID_API_KEY environment variable must be set")
        
        self.sg = SendGridAPIClient(self.sendgrid_key)
        # Use verified sender email from environment variable
        self.from_email = os.environ.get('FROM_EMAIL')
        if not self.from_email:
            raise ValueError("FROM_EMAIL environment variable must be set to a verified SendGrid sender address")
        
        # Email templates
        self.templates = {
            'audit_complete': {
                'subject': 'RateWise Audit Complete - ${total_savings} in Potential Savings Found!',
                'template': self._get_audit_complete_template()
            },
            'weekly_summary': {
                'subject': 'RateWise Weekly Summary - ${period_savings} This Week',
                'template': self._get_weekly_summary_template()
            },
            'monthly_report': {
                'subject': 'RateWise Monthly Report - ${period_savings} in Savings Identified',
                'template': self._get_monthly_report_template()
            },
            'claim_submission': {
                'subject': 'New Refund Claims Submitted - ${total_claims} Claims | ${total_recovery} Recovery',
                'template': self._get_claim_submission_template()
            }
        }
    
    def send_audit_complete_email(self, 
                                  to_email: str, 
                                  audit_results: Dict[str, Any],
                                  findings_df: pd.DataFrame,
                                  user_name: str,
                                  company_name: str = None,
                                  pdf_attachment: bytes = None) -> bool:
        """
        Send audit completion email with results summary
        
        Args:
            to_email: Recipient email address
            audit_results: Audit results dictionary
            findings_df: DataFrame with detailed findings
            user_name: Name of the user
            company_name: Optional company name
            pdf_attachment: Optional PDF report attachment
            
        Returns:
            bool: Success status
        """
        try:
            # Prepare template variables
            template_vars = {
                'user_name': user_name,
                'company_name': company_name or 'Your Company',
                'total_savings': self._format_currency(audit_results.get('summary', {}).get('total_savings', 0)),
                'total_findings': len(findings_df),
                'affected_shipments': audit_results.get('summary', {}).get('affected_shipments', 0),
                'total_shipments': audit_results.get('summary', {}).get('total_shipments', 0),
                'audit_date': datetime.now().strftime('%B %d, %Y'),
                'findings_summary': self._generate_findings_summary(findings_df)
            }
            
            # Generate email content
            subject = self._replace_template_vars(
                self.templates['audit_complete']['subject'], 
                template_vars
            )
            
            html_content = self._replace_template_vars(
                self.templates['audit_complete']['template'], 
                template_vars
            )
            
            # Create email using official SendGrid pattern
            message = Mail(
                from_email=self.from_email,
                to_emails=to_email,
                subject=subject,
                html_content=html_content
            )
            
            # Add PDF attachment if provided
            if pdf_attachment:
                attachment = Attachment()
                attachment.file_content = FileContent(base64.b64encode(pdf_attachment).decode())
                attachment.file_type = FileType('application/pdf')
                attachment.file_name = FileName(f'RateWise_Audit_Report_{datetime.now().strftime("%Y%m%d")}.pdf')
                attachment.disposition = Disposition('attachment')
                message.add_attachment(attachment)
            
            # Send email using official SendGrid pattern
            response = self.sg.send(message)
            print(f"SendGrid audit email response status: {response.status_code}")
            return response.status_code == 202
            
        except Exception as e:
            # Use official SendGrid error handling pattern
            print(f"SendGrid audit email error: {e}")
            if hasattr(e, 'message'):
                print(f"Error message: {e.message}")
            else:
                print(f"Error details: {str(e)}")
            return False
    
    def send_claim_submission_email(self, 
                                   claims_data: List[Dict[str, Any]],
                                   user_name: str,
                                   company_name: str = None,
                                   submission_method: str = "Automatic Submission") -> bool:
        """
        Send claim submission email to RateWise team
        
        Args:
            claims_data: List of claim dictionaries with details
            user_name: Name of the user submitting claims
            company_name: Optional company name
            submission_method: Method used for submission
            
        Returns:
            bool: Success status
        """
        try:
            # Calculate totals
            total_claims = len(claims_data)
            total_recovery = sum(claim.get('refund_estimate', 0) for claim in claims_data)
            
            # Prepare template variables
            template_vars = {
                'user_name': user_name,
                'company_name': company_name or 'N/A',
                'total_claims': total_claims,
                'total_recovery': self._format_currency(total_recovery),
                'submission_method': submission_method,
                'submission_date': datetime.now().strftime('%B %d, %Y at %I:%M %p'),
                'claims_details': self._generate_claims_summary(claims_data)
            }
            
            # Generate email content
            subject = self._replace_template_vars(
                self.templates['claim_submission']['subject'], 
                template_vars
            )
            
            html_content = self._replace_template_vars(
                self.templates['claim_submission']['template'], 
                template_vars
            )
            
            # Create email to RateWise team using official SendGrid pattern
            message = Mail(
                from_email=self.from_email,
                to_emails='Audit@ratewiseconsulting.com',
                subject=subject,
                html_content=html_content
            )
            
            # Send email using official SendGrid pattern
            response = self.sg.send(message)
            print(f"SendGrid response status: {response.status_code}")
            print(f"SendGrid response body: {response.body}")
            print(f"SendGrid response headers: {response.headers}")
            return response.status_code == 202
            
        except Exception as e:
            # Use official SendGrid error handling pattern
            print(f"SendGrid error: {e}")
            if hasattr(e, 'message'):
                print(f"Error message: {e.message}")
            else:
                print(f"Error details: {str(e)}")
            # Log detailed error for debugging
            import traceback
            print(f"Full error traceback: {traceback.format_exc()}")
            return False
    
    def send_scheduled_report(self, 
                             to_emails: List[str], 
                             report_type: str,
                             period_data: Dict[str, Any],
                             user_name: str,
                             company_name: str = None) -> bool:
        """
        Send scheduled reports (weekly/monthly)
        
        Args:
            to_emails: List of recipient email addresses
            report_type: Type of report ('weekly' or 'monthly')
            period_data: Data for the reporting period
            user_name: Name of the user
            company_name: Optional company name
            
        Returns:
            bool: Success status
        """
        try:
            if report_type not in ['weekly_summary', 'monthly_report']:
                raise ValueError("Invalid report type")
            
            # Prepare template variables
            template_vars = {
                'user_name': user_name,
                'company_name': company_name or 'Your Company',
                'period_savings': self._format_currency(period_data.get('total_savings', 0)),
                'period_findings': period_data.get('total_findings', 0),
                'period_audits': period_data.get('total_audits', 0),
                'report_period': period_data.get('period_description', ''),
                'top_carriers': period_data.get('top_carriers', []),
                'top_error_types': period_data.get('top_error_types', []),
                'report_date': datetime.now().strftime('%B %d, %Y')
            }
            
            # Generate email content
            template_config = self.templates[report_type]
            subject = self._replace_template_vars(template_config['subject'], template_vars)
            html_content = self._replace_template_vars(template_config['template'], template_vars)
            
            # Send to each recipient
            success_count = 0
            for email in to_emails:
                message = Mail(
                    from_email=Email(self.from_email, "RateWise Reports"),
                    to_emails=To(email),
                    subject=subject,
                    html_content=html_content
                )
                
                response = self.sg.send(message)
                if response.status_code == 202:
                    success_count += 1
            
            return success_count == len(to_emails)
            
        except Exception as e:
            print(f"Scheduled report sending error: {e}")
            return False
    
    def send_notification_email(self, 
                               to_email: str, 
                               subject: str, 
                               message: str,
                               html_message: str = None) -> bool:
        """
        Send a general notification email
        
        Args:
            to_email: Recipient email address
            subject: Email subject
            message: Plain text message
            html_message: Optional HTML message
            
        Returns:
            bool: Success status
        """
        try:
            email = Mail(
                from_email=Email(self.from_email, "RateWise Notifications"),
                to_emails=To(to_email),
                subject=subject,
                plain_text_content=message,
                html_content=html_message or message
            )
            
            response = self.sg.send(email)
            return response.status_code == 202
            
        except Exception as e:
            print(f"Notification email error: {e}")
            return False
    
    def _get_audit_complete_template(self) -> str:
        """Get HTML template for audit completion emails"""
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
                .container { max-width: 600px; margin: 0 auto; background-color: white; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
                .header { background: linear-gradient(90deg, #1F497D 0%, #FFA947 100%); color: white; padding: 30px; text-align: center; }
                .content { padding: 30px; }
                .metrics { display: flex; justify-content: space-around; margin: 20px 0; }
                .metric { text-align: center; padding: 15px; background-color: #f8f9fa; border-radius: 8px; margin: 0 5px; }
                .metric-value { font-size: 24px; font-weight: bold; color: #1F497D; }
                .metric-label { font-size: 12px; color: #666; }
                .findings { margin: 20px 0; padding: 15px; background-color: #fff5f5; border-left: 4px solid #FFA947; }
                .footer { background-color: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1> RateWise Audit Complete!</h1>
                    <p>Your freight audit has identified significant savings opportunities</p>
                </div>
                
                <div class="content">
                    <h2>Hi ${user_name},</h2>
                    
                    <p>Great news! We've completed your freight audit for <strong>${company_name}</strong> and found substantial savings opportunities.</p>
                    
                    <div class="metrics">
                        <div class="metric">
                            <div class="metric-value">${total_savings}</div>
                            <div class="metric-label">Total Potential Savings</div>
                        </div>
                        <div class="metric">
                            <div class="metric-value">${total_findings}</div>
                            <div class="metric-label">Billing Errors Found</div>
                        </div>
                        <div class="metric">
                            <div class="metric-value">${affected_shipments}</div>
                            <div class="metric-label">Affected Shipments</div>
                        </div>
                    </div>
                    
                    <div class="findings">
                        <h3> Findings Summary</h3>
                        ${findings_summary}
                    </div>
                    
                    <h3> Next Steps</h3>
                    <ul>
                        <li><strong>Review Results:</strong> Login to your RateWise dashboard to explore detailed findings</li>
                        <li><strong>Generate Reports:</strong> Create professional dispute reports for carrier submissions</li>
                        <li><strong>Export to QuickBooks:</strong> Seamlessly integrate findings into your accounting system</li>
                        <li><strong>Track Progress:</strong> Monitor refund status and savings realization</li>
                    </ul>
                    
                    <p><strong>Questions?</strong> Our freight audit experts are here to help you maximize your savings recovery.</p>
                </div>
                
                <div class="footer">
                    <p>This audit was completed on ${audit_date} | RateWise Freight Audit Platform</p>
                    <p>© ${audit_date} RateWise. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        """
    
    def _get_weekly_summary_template(self) -> str:
        """Get HTML template for weekly summary emails"""
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
                .container { max-width: 600px; margin: 0 auto; background-color: white; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
                .header { background: linear-gradient(90deg, #1F497D 0%, #FFA947 100%); color: white; padding: 20px; text-align: center; }
                .content { padding: 30px; }
                .summary-box { background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 15px 0; }
                .footer { background-color: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1> Weekly RateWise Summary</h1>
                    <p>Your freight savings performance this week</p>
                </div>
                
                <div class="content">
                    <h2>Hi ${user_name},</h2>
                    
                    <p>Here's your weekly RateWise summary for <strong>${company_name}</strong>:</p>
                    
                    <div class="summary-box">
                        <h3> This Week's Results</h3>
                        <ul>
                            <li><strong>Total Savings Identified:</strong> ${period_savings}</li>
                            <li><strong>Billing Errors Found:</strong> ${period_findings}</li>
                            <li><strong>Audits Completed:</strong> ${period_audits}</li>
                        </ul>
                    </div>
                    
                    <p><strong>Keep up the great work!</strong> Regular auditing helps you stay on top of carrier billing errors and maximize your freight savings.</p>
                    
                    <p>Login to your RateWise dashboard to explore detailed insights and generate reports.</p>
                </div>
                
                <div class="footer">
                    <p>Report generated on ${report_date} | RateWise Weekly Summary</p>
                </div>
            </div>
        </body>
        </html>
        """
    
    def _get_monthly_report_template(self) -> str:
        """Get HTML template for monthly report emails"""
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
                .container { max-width: 600px; margin: 0 auto; background-color: white; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
                .header { background: linear-gradient(90deg, #1F497D 0%, #FFA947 100%); color: white; padding: 30px; text-align: center; }
                .content { padding: 30px; }
                .highlight-box { background-color: #e8f4fd; padding: 20px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #1F497D; }
                .insights-box { background-color: #fff5f5; padding: 20px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #FFA947; }
                .footer { background-color: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1> Monthly RateWise Report</h1>
                    <p>Comprehensive freight audit insights for ${report_period}</p>
                </div>
                
                <div class="content">
                    <h2>Hi ${user_name},</h2>
                    
                    <p>Here's your comprehensive monthly report for <strong>${company_name}</strong>:</p>
                    
                    <div class="highlight-box">
                        <h3> Monthly Performance</h3>
                        <ul>
                            <li><strong>Total Savings Identified:</strong> ${period_savings}</li>
                            <li><strong>Total Billing Errors:</strong> ${period_findings}</li>
                            <li><strong>Audits Completed:</strong> ${period_audits}</li>
                        </ul>
                    </div>
                    
                    <div class="insights-box">
                        <h3> Key Insights</h3>
                        <p><strong>Top Error Types:</strong> ${top_error_types}</p>
                        <p><strong>Problematic Carriers:</strong> ${top_carriers}</p>
                        <p>Focus your attention on these areas for maximum savings impact.</p>
                    </div>
                    
                    <h3> Recommendations</h3>
                    <ul>
                        <li>Schedule regular audits to catch errors early</li>
                        <li>Review carrier performance and consider contract negotiations</li>
                        <li>Implement automated auditing for continuous monitoring</li>
                    </ul>
                    
                    <p>Access your full dashboard for detailed analytics and export capabilities.</p>
                </div>
                
                <div class="footer">
                    <p>Monthly report for ${report_period} | Generated on ${report_date}</p>
                </div>
            </div>
        </body>
        </html>
        """
    
    def _generate_findings_summary(self, findings_df: pd.DataFrame) -> str:
        """Generate HTML summary of audit findings"""
        if findings_df.empty:
            return "<p>No billing errors found in this audit.</p>"
        
        summary_html = "<ul>"
        
        # Group by error type
        error_summary = findings_df.groupby('Error Type').agg({
            'Refund Estimate': ['count', 'sum']
        }).round(2)
        
        for error_type, data in error_summary.iterrows():
            count = int(data[('Refund Estimate', 'count')])
            amount = data[('Refund Estimate', 'sum')]
            summary_html += f"<li><strong>{error_type}:</strong> {count} errors worth {self._format_currency(amount)}</li>"
        
        summary_html += "</ul>"
        return summary_html
    
    def _get_claim_submission_template(self) -> str:
        """Get HTML template for claim submission emails to RateWise team"""
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
                .container { max-width: 700px; margin: 0 auto; background-color: white; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
                .header { background: linear-gradient(90deg, #1F497D 0%, #FFA947 100%); color: white; padding: 30px; text-align: center; }
                .content { padding: 30px; }
                .metrics { display: flex; justify-content: space-around; margin: 20px 0; }
                .metric { text-align: center; padding: 15px; background-color: #f8f9fa; border-radius: 8px; margin: 0 5px; }
                .metric-value { font-size: 24px; font-weight: bold; color: #1F497D; }
                .metric-label { font-size: 12px; color: #666; }
                .claims-box { margin: 20px 0; padding: 20px; background-color: #fff5f5; border-left: 4px solid #FFA947; border-radius: 8px; }
                .client-info { margin: 15px 0; padding: 15px; background-color: #e8f4fd; border-radius: 8px; }
                .footer { background-color: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #666; }
                .urgency { background-color: #ffebee; border: 2px solid #e57373; padding: 15px; border-radius: 8px; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1> New Refund Claims Submitted</h1>
                    <p>Client has submitted claims for carrier billing errors</p>
                </div>
                
                <div class="content">
                    <h2>New Claims Alert</h2>
                    
                    <div class="client-info">
                        <h3> Client Information</h3>
                        <ul>
                            <li><strong>Client Name:</strong> ${user_name}</li>
                            <li><strong>Company:</strong> ${company_name}</li>
                            <li><strong>Submission Date:</strong> ${submission_date}</li>
                            <li><strong>Submission Method:</strong> ${submission_method}</li>
                        </ul>
                    </div>
                    
                    <div class="metrics">
                        <div class="metric">
                            <div class="metric-value">${total_claims}</div>
                            <div class="metric-label">Total Claims</div>
                        </div>
                        <div class="metric">
                            <div class="metric-value">${total_recovery}</div>
                            <div class="metric-label">Potential Recovery</div>
                        </div>
                    </div>
                    
                    <div class="claims-box">
                        <h3> Claims Details</h3>
                        ${claims_details}
                    </div>
                    
                    <div class="urgency">
                        <h3> Next Steps Required</h3>
                        <ul>
                            <li><strong>Review Claims:</strong> Verify claim details and supporting documentation</li>
                            <li><strong>Prepare Disputes:</strong> Generate professional dispute letters for carriers</li>
                            <li><strong>Submit to Carriers:</strong> File claims with appropriate shipping companies</li>
                            <li><strong>Track Progress:</strong> Monitor claim status and follow up as needed</li>
                            <li><strong>Update Client:</strong> Provide status updates and recovery notifications</li>
                        </ul>
                    </div>
                    
                    <p><strong>Priority:</strong> High-value claims require immediate attention for maximum recovery success.</p>
                    <p><strong>Contact Client:</strong> Reach out if additional documentation or clarification is needed.</p>
                </div>
                
                <div class="footer">
                    <p>Claims submitted via RateWise Platform on ${submission_date}</p>
                    <p>© RateWise Consulting - Freight Audit & Recovery Services</p>
                </div>
            </div>
        </body>
        </html>
        """
    
    def _generate_claims_summary(self, claims_data: List[Dict[str, Any]]) -> str:
        """Generate HTML summary of submitted claims"""
        if not claims_data:
            return "<p>No claims data available.</p>"
        
        summary_html = "<div style='max-height: 400px; overflow-y: auto;'>"
        
        for i, claim in enumerate(claims_data, 1):
            tracking = claim.get('tracking_number', 'N/A')
            error_type = claim.get('error_type', 'Unknown')
            carrier = claim.get('carrier', 'N/A')
            refund = claim.get('refund_estimate', 0)
            
            summary_html += f"""
            <div style="border: 1px solid #ddd; border-radius: 6px; padding: 12px; margin: 10px 0; background-color: #fafafa;">
                <strong>Claim #{i}</strong><br>
                <strong>Tracking:</strong> {tracking}<br>
                <strong>Error Type:</strong> {error_type}<br>
                <strong>Carrier:</strong> {carrier}<br>
                <strong>Refund Amount:</strong> {self._format_currency(refund)}
            </div>
            """
        
        summary_html += "</div>"
        return summary_html
    
    def _replace_template_vars(self, template: str, variables: Dict[str, Any]) -> str:
        """Replace template variables with actual values"""
        result = template
        for key, value in variables.items():
            result = result.replace(f"${{{key}}}", str(value))
        return result
    
    def _format_currency(self, amount: float) -> str:
        """Format currency values"""
        return f"${amount:,.2f}"
    
    def test_email_connection(self) -> bool:
        """Test SendGrid connection"""
        try:
            # Try to send a test email to verify connection
            test_message = Mail(
                from_email=Email(self.from_email, "RateWise Test"),
                to_emails=To("test@example.com"),  # This won't actually send
                subject="Connection Test",
                plain_text_content="Test message"
            )
            # Just validate the message creation
            return True
        except Exception as e:
            print(f"Email connection test failed: {e}")
            return False