# RateWise User Guide
## Complete Freight Audit Platform Instructions

---

## Table of Contents
1. [Getting Started](#getting-started)
2. [Authentication & Access](#authentication--access)
3. [File Upload Options](#file-upload-options)
4. [Audit Process](#audit-process)
5. [Results & Reports](#results--reports)
6. [Advanced Features](#advanced-features)
7. [Troubleshooting](#troubleshooting)

---

## Getting Started

### Accessing RateWise
1. **Open your web browser** and navigate to your RateWise application
2. **Enter your access password** when prompted
3. **Choose your audit method** from the main dashboard

### System Requirements
- **Supported File Types**: CSV, Excel (.xlsx, .xls)
- **Maximum File Size**: 50MB per file
- **Supported Browsers**: Chrome, Firefox, Safari, Edge
- **Internet Connection**: Required for processing and reports

---

## Authentication & Access

### Free Trial Access
- **Password**: `FREEAUDIT25`
- **Features**: Basic audit functionality, limited file processing
- **Limitations**: Reduced analysis depth, basic reporting

### Full Access
- **Password**: `RATEWISE2025`
- **Features**: Complete audit suite, advanced analytics, professional reports
- **Benefits**: Full surcharge analysis, contract review, unlimited processing

---

## File Upload Options

### Option 1: Single File Upload (Standard)
**Best for**: Complete shipment data with all charges included

**Required Columns**:
- `Tracking Number` (or `Tracking`, `Track Number`)
- `Shipment Date`
- `Delivery Date`
- `Carrier` (FedEx, UPS, etc.)
- `Service Type`
- `Total Charges`

**Optional Columns**:
- `Recipient Address`, `ZIP Code`
- `Package Weight`, `DIM Weight`
- `Length`, `Width`, `Height`
- `Declared Value`

### Option 2: File Merge (Advanced)
**Best for**: Separate shipment details and surcharge reports

#### Shipment Details File
**Required Columns**:
- `Tracking Number`
- `Shipment Date`
- `Delivery Date`
- `Carrier`
- `Service Type`
- `Base Charges` (without surcharges)

#### Surcharge Report File
**Required Columns**:
- `Tracking Number` (must match shipment file)
- `Description` (or `Type`, `Surcharge Type`)
- `Amount` (or `Charge`, `Cost`)

**Supported Amount Formats**:
- `$14.75` (currency symbol)
- `(5.00)` (parentheses for credits)
- `1,234.56` (comma separators)
- `14.75` (plain numbers)

---

## Audit Process

### Step 1: Upload Your Data
1. **Choose Upload Method**: Single file or file merge
2. **Select Files**: Browse and upload your data files
3. **Verify Columns**: System will display detected columns
4. **Confirm Upload**: Proceed once validation passes

### Step 2: Data Validation
The system automatically:
- ✅ **Validates required columns** are present
- ✅ **Cleans data formats** (dates, numbers, text)
- ✅ **Standardizes carriers** (FedEx, UPS, USPS, DHL)
- ✅ **Normalizes service types**
- ✅ **Processes tracking numbers**

### Step 3: Run Freight Audit
Click **"Run Freight Audit"** to begin analysis:
- **Late Deliveries**: Service guarantee violations
- **DIM Weight Errors**: Calculation mistakes
- **Zone Mismatches**: Incorrect shipping zones
- **Duplicate Charges**: Billing duplicates
- **Disputable Surcharges**: Questionable fees
- **Service Mismatches**: Billed vs actual service

### Step 4: Review Results
Access your audit findings through:
- **Dashboard Overview**: Summary metrics and charts
- **Detailed Findings**: Line-by-line error analysis
- **Actionable Items**: Refund-eligible errors only

---

## Results & Reports

### Dashboard Metrics
- **Total Charges Audited**: Complete spend analysis
- **Potential Savings**: Estimated refund opportunities
- **Error Rate**: Percentage of shipments with issues
- **Carrier Performance**: Breakdown by shipping provider

### Detailed Findings
Each error includes:
- **Error Type**: Category of issue found
- **Tracking Number**: Specific shipment affected
- **Date**: When shipment occurred
- **Carrier & Service**: Shipping details
- **Dispute Reason**: Specific problem identified
- **Refund Estimate**: Potential recovery amount
- **Supporting Notes**: Additional context

### Export Options

#### PDF Dispute Reports
- **Professional formatting** for carrier submissions
- **Detailed evidence** supporting each claim
- **Company branding** and contact information
- **Ready-to-submit** documentation

#### CSV Data Export
- **Complete findings** in spreadsheet format
- **QuickBooks compatible** journal entries
- **Filterable data** for internal analysis
- **Bulk processing** support

#### Email Reports
- **Automated delivery** to specified recipients
- **Executive summaries** with key metrics
- **Detailed attachments** with full analysis
- **Scheduled reporting** options

---

## Advanced Features

### Surcharge Analysis Engine
Identifies disputable charges including:

#### Residential Delivery Errors
- **Detection**: Business addresses charged residential rates
- **Common Indicators**: LLC, Inc, Corp, Company in address
- **Refund Potential**: Full surcharge amount

#### Address Correction Fees
- **Detection**: Questionable address corrections
- **Success Rate**: 80% refund chance
- **Examples**: Minor address variations, valid addresses

#### Additional Handling Charges
- **Detection**: Charges not justified by package specs
- **Validation**: Against actual dimensions and weight
- **Refund Potential**: 60% of charge amount

#### Excessive Fuel Surcharges
- **Detection**: Surcharges over 25% of base rate
- **Industry Standard**: 10-20% typical range
- **Refund Potential**: Partial reduction of excessive amount

#### Duplicate Surcharges
- **Detection**: Identical charges within same tracking number
- **Examples**: Double residential fees, multiple fuel charges
- **Refund Potential**: Full amount of duplicates

### File Merge Benefits
- **Comprehensive Analysis**: Combines shipment and surcharge data
- **Detailed Breakdown**: Individual surcharge examination
- **Enhanced Detection**: More granular error identification
- **Professional Reporting**: Complete charge documentation

### Contract Analysis (Full Access)
- **Rate Benchmarking**: Industry comparison analysis
- **Health Scoring**: A-F contract performance grades
- **Negotiation Strategy**: Professional recommendations
- **Savings Projections**: Potential cost reductions

---

## Troubleshooting

### Common File Issues

#### "Column Not Found" Errors
**Solution**: Ensure your file includes required columns:
- Check column spelling and spacing
- Verify first row contains headers
- Remove any empty rows at top of file

#### "Failed to Load File" Errors
**Solution**: Check file format and content:
- Use CSV or Excel formats only
- Ensure file is not corrupted
- Check file size under 50MB limit
- Verify file contains actual data

#### "No Data Found" Warnings
**Solution**: Verify file structure:
- Confirm tracking numbers are present
- Check date formats (YYYY-MM-DD preferred)
- Ensure numeric columns contain numbers

### File Merge Issues

#### "Could Not Find Tracking Column"
**Solution**: Update surcharge file headers:
- Include word "tracking" in column name
- Examples: "Tracking Number", "Tracking", "Track #"

#### "Tracking Numbers Don't Match"
**Solution**: Standardize tracking formats:
- Remove spaces and special characters
- Use identical formats in both files
- Check for leading/trailing spaces

#### "No Surcharges Found"
**Solution**: Verify surcharge file format:
- Include amount column with keyword: "amount", "charge", "cost"
- Include description column: "description", "type", "service"
- Ensure amounts are in numeric or currency format

### Performance Issues

#### Slow Processing
**Solutions**:
- Break large files into smaller chunks
- Remove unnecessary columns before upload
- Use CSV format for faster processing
- Ensure stable internet connection

#### Memory Errors
**Solutions**:
- Reduce file size under 50MB
- Close other browser tabs
- Refresh page and retry
- Contact support for large datasets

### Data Quality Issues

#### Inaccurate Results
**Check These Items**:
- Verify carrier names are standard (FedEx, UPS, etc.)
- Confirm service types match carrier offerings
- Validate date formats and ranges
- Check ZIP codes are 5-digit format

#### Missing Findings
**Possible Causes**:
- Data doesn't meet error detection criteria
- Incomplete shipment information
- Already-corrected billing data
- Service guarantee exclusions apply

---

## Getting Help

### Support Resources
- **Built-in Validation**: Real-time feedback during upload
- **Error Messages**: Specific guidance for issues
- **Sample Files**: Download examples for reference
- **Documentation**: Complete user guides and FAQs

### Best Practices
1. **Clean Your Data**: Remove empty rows and standardize formats
2. **Use Standard Headers**: Follow recommended column names
3. **Validate Dates**: Use consistent date formatting
4. **Check File Size**: Keep under 50MB for optimal performance
5. **Review Results**: Manually verify significant findings

### Tips for Success
- **Start Small**: Test with a small file first
- **Use File Merge**: For more detailed surcharge analysis
- **Regular Audits**: Process data monthly or quarterly
- **Track Patterns**: Monitor recurring issues by carrier
- **Follow Up**: Submit claims promptly for best results

---

## Conclusion

RateWise provides comprehensive freight audit capabilities designed to maximize your refund opportunities while minimizing manual effort. With advanced surcharge analysis, professional reporting, and seamless file processing, you can confidently identify and recover shipping overcharges.

**Ready to save money on shipping?** Upload your first file and discover what you've been missing!

---

*Last Updated: September 2025*
*Version: 2.0*