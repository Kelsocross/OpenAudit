# RateWise - Company Deployment

This is a complete, independent copy of the RateWise freight audit application.

## How to Deploy

### Option 1: Move to New Replit (Recommended)
1. Create a new Replit
2. Copy all files from this `company_app/` folder to the root of your new Replit
3. Install Python packages (see requirements below)
4. Configure workflow to run: `streamlit run app.py --server.port 5000`
5. Customize passwords and branding (see below)

### Option 2: Run in This Replit
1. Update the workflow configuration to use this directory
2. Change workflow command to: `cd company_app && streamlit run app.py --server.port 5000`

## Required Python Packages

Install these packages in your new Replit:
- streamlit
- pandas
- numpy
- plotly
- matplotlib
- sqlalchemy
- psycopg2-binary
- sendgrid
- openai
- reportlab
- pdfplumber
- tabula-py
- openpyxl
- python-dateutil
- regex

## Customization

### Change Passwords
Edit `auth.py` and update:
- `FREE_TRIAL_PASSWORD = "FREEAUDIT25"` → Your free trial password
- `FULL_ACCESS_PASSWORD = "RATEWISE2025"` → Your full access password

### Change Branding
Edit `app.py` and update:
- Company name: Search for "RateWise" and replace
- Colors: Update the CSS variables:
  - Primary Blue: `#1F497D`
  - Primary Orange: `#FFA947`
  - Light Blue: `#4A90E2`

### Email Settings
Set environment variables (Secrets in Replit):
- `SENDGRID_API_KEY` - Your SendGrid API key
- `FROM_EMAIL` - Your sender email address

## Database

The app will automatically create a SQLite database on first run.
For production use, configure PostgreSQL via DATABASE_URL environment variable.

## Support

This is a standalone application. All features are included and ready to use.
